﻿namespace Hox
{
    partial class RutAlt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        	this.components = new System.ComponentModel.Container();
        	this.ListHostVistuales = new System.Windows.Forms.ListView();
        	this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
        	this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
        	this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
        	this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
        	this.agregarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.Modificar = new System.Windows.Forms.ToolStripMenuItem();
        	this.eliminarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.BtbAgregar = new System.Windows.Forms.Button();
        	this.BtnDelete = new System.Windows.Forms.Button();
        	this.BtnCancel = new System.Windows.Forms.Button();
        	this.contextMenuStrip1.SuspendLayout();
        	this.SuspendLayout();
        	// 
        	// ListHostVistuales
        	// 
        	this.ListHostVistuales.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
			this.columnHeader1,
			this.columnHeader2,
			this.columnHeader3});
        	this.ListHostVistuales.ContextMenuStrip = this.contextMenuStrip1;
        	this.ListHostVistuales.Font = new System.Drawing.Font("Tahoma", 11.25F);
        	this.ListHostVistuales.FullRowSelect = true;
        	this.ListHostVistuales.Location = new System.Drawing.Point(9, 12);
        	this.ListHostVistuales.Name = "ListHostVistuales";
        	this.ListHostVistuales.Size = new System.Drawing.Size(512, 286);
        	this.ListHostVistuales.TabIndex = 8;
        	this.ListHostVistuales.UseCompatibleStateImageBehavior = false;
        	this.ListHostVistuales.View = System.Windows.Forms.View.Details;
        	// 
        	// columnHeader1
        	// 
        	this.columnHeader1.Text = "Dominio";
        	this.columnHeader1.Width = 142;
        	// 
        	// columnHeader2
        	// 
        	this.columnHeader2.Text = "Ruta";
        	this.columnHeader2.Width = 241;
        	// 
        	// columnHeader3
        	// 
        	this.columnHeader3.Text = "Tipo";
        	this.columnHeader3.Width = 122;
        	// 
        	// contextMenuStrip1
        	// 
        	this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.agregarToolStripMenuItem,
			this.Modificar,
			this.eliminarToolStripMenuItem});
        	this.contextMenuStrip1.Name = "contextMenuStrip1";
        	this.contextMenuStrip1.Size = new System.Drawing.Size(126, 70);
        	// 
        	// agregarToolStripMenuItem
        	// 
        	this.agregarToolStripMenuItem.Name = "agregarToolStripMenuItem";
        	this.agregarToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
        	this.agregarToolStripMenuItem.Text = "Agregar";
        	// 
        	// Modificar
        	// 
        	this.Modificar.Name = "Modificar";
        	this.Modificar.Size = new System.Drawing.Size(125, 22);
        	this.Modificar.Text = "Modificar";
        	// 
        	// eliminarToolStripMenuItem
        	// 
        	this.eliminarToolStripMenuItem.Name = "eliminarToolStripMenuItem";
        	this.eliminarToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
        	this.eliminarToolStripMenuItem.Text = "Eliminar";
        	// 
        	// BtbAgregar
        	// 
        	this.BtbAgregar.Location = new System.Drawing.Point(454, 304);
        	this.BtbAgregar.Name = "BtbAgregar";
        	this.BtbAgregar.Size = new System.Drawing.Size(67, 30);
        	this.BtbAgregar.TabIndex = 9;
        	this.BtbAgregar.Text = "Agregar";
        	this.BtbAgregar.UseVisualStyleBackColor = true;
        	// 
        	// BtnDelete
        	// 
        	this.BtnDelete.Location = new System.Drawing.Point(381, 304);
        	this.BtnDelete.Name = "BtnDelete";
        	this.BtnDelete.Size = new System.Drawing.Size(67, 30);
        	this.BtnDelete.TabIndex = 10;
        	this.BtnDelete.Text = "Eliminar";
        	this.BtnDelete.UseVisualStyleBackColor = true;
        	// 
        	// BtnCancel
        	// 
        	this.BtnCancel.Location = new System.Drawing.Point(308, 304);
        	this.BtnCancel.Name = "BtnCancel";
        	this.BtnCancel.Size = new System.Drawing.Size(67, 30);
        	this.BtnCancel.TabIndex = 11;
        	this.BtnCancel.Text = "Cancelar";
        	this.BtnCancel.UseVisualStyleBackColor = true;
        	// 
        	// RutAlt
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.ClientSize = new System.Drawing.Size(531, 346);
        	this.Controls.Add(this.BtnCancel);
        	this.Controls.Add(this.BtnDelete);
        	this.Controls.Add(this.BtbAgregar);
        	this.Controls.Add(this.ListHostVistuales);
        	this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
        	this.MaximizeBox = false;
        	this.MinimizeBox = false;
        	this.Name = "RutAlt";
        	this.ShowIcon = false;
        	this.ShowInTaskbar = false;
        	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        	this.Text = "Dominios locales";
        	this.contextMenuStrip1.ResumeLayout(false);
        	this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView ListHostVistuales;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button BtbAgregar;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem eliminarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Modificar;
        private System.Windows.Forms.Button BtnCancel;
    }
}