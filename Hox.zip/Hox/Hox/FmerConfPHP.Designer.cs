﻿namespace Hox
{
    partial class FmerConfPHP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ListExtension = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CheckAviso = new System.Windows.Forms.CheckBox();
            this.CheckEstric = new System.Windows.Forms.CheckBox();
            this.ChekAdver = new System.Windows.Forms.CheckBox();
            this.BtbnGuardar = new System.Windows.Forms.Button();
            this.BtbCancelar = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(2, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(636, 302);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ListExtension);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(628, 276);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Extenciones PHP";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // ListExtension
            // 
            this.ListExtension.CheckBoxes = true;
            this.ListExtension.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.ListExtension.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ListExtension.FullRowSelect = true;
            this.ListExtension.Location = new System.Drawing.Point(3, 3);
            this.ListExtension.MultiSelect = false;
            this.ListExtension.Name = "ListExtension";
            this.ListExtension.Size = new System.Drawing.Size(622, 270);
            this.ListExtension.TabIndex = 0;
            this.ListExtension.UseCompatibleStateImageBehavior = false;
            this.ListExtension.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Extexiòn";
            this.columnHeader1.Width = 203;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Ruta";
            this.columnHeader2.Width = 312;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Disponiblidad";
            this.columnHeader3.Width = 89;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(628, 276);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Opciones";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CheckAviso);
            this.groupBox1.Controls.Add(this.CheckEstric);
            this.groupBox1.Controls.Add(this.ChekAdver);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(197, 110);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Depuraciòn";
            // 
            // CheckAviso
            // 
            this.CheckAviso.AutoSize = true;
            this.CheckAviso.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAviso.Location = new System.Drawing.Point(6, 20);
            this.CheckAviso.Name = "CheckAviso";
            this.CheckAviso.Size = new System.Drawing.Size(52, 17);
            this.CheckAviso.TabIndex = 2;
            this.CheckAviso.Text = "Aviso";
            this.CheckAviso.UseVisualStyleBackColor = true;
            // 
            // CheckEstric
            // 
            this.CheckEstric.AutoSize = true;
            this.CheckEstric.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckEstric.Location = new System.Drawing.Point(73, 20);
            this.CheckEstric.Name = "CheckEstric";
            this.CheckEstric.Size = new System.Drawing.Size(121, 17);
            this.CheckEstric.TabIndex = 2;
            this.CheckEstric.Text = "Estàndares estrictos";
            this.CheckEstric.UseVisualStyleBackColor = true;
            // 
            // ChekAdver
            // 
            this.ChekAdver.AutoSize = true;
            this.ChekAdver.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChekAdver.Location = new System.Drawing.Point(6, 43);
            this.ChekAdver.Name = "ChekAdver";
            this.ChekAdver.Size = new System.Drawing.Size(83, 17);
            this.ChekAdver.TabIndex = 3;
            this.ChekAdver.Text = "Advertencia";
            this.ChekAdver.UseVisualStyleBackColor = true;
            // 
            // BtbnGuardar
            // 
            this.BtbnGuardar.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtbnGuardar.Location = new System.Drawing.Point(557, 314);
            this.BtbnGuardar.Name = "BtbnGuardar";
            this.BtbnGuardar.Size = new System.Drawing.Size(75, 23);
            this.BtbnGuardar.TabIndex = 1;
            this.BtbnGuardar.Text = "Aceptar";
            this.BtbnGuardar.UseVisualStyleBackColor = true;
            // 
            // BtbCancelar
            // 
            this.BtbCancelar.Location = new System.Drawing.Point(476, 315);
            this.BtbCancelar.Name = "BtbCancelar";
            this.BtbCancelar.Size = new System.Drawing.Size(75, 23);
            this.BtbCancelar.TabIndex = 2;
            this.BtbCancelar.Text = "Cancelar";
            this.BtbCancelar.UseVisualStyleBackColor = true;
            // 
            // FmerConfPHP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 345);
            this.Controls.Add(this.BtbCancelar);
            this.Controls.Add(this.BtbnGuardar);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FmerConfPHP";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configurar PHP";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button BtbnGuardar;
        private System.Windows.Forms.Button BtbCancelar;
        private System.Windows.Forms.ListView ListExtension;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox CheckAviso;
        private System.Windows.Forms.CheckBox CheckEstric;
        private System.Windows.Forms.CheckBox ChekAdver;
    }
}