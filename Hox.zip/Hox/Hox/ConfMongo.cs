﻿//Entorno de desarrollo para aplicaciones web Alternativa a Xampp, Wamp Appserv y demás, 
// Copyright (C ) Rodrigo Chambi Q, Email infohoxserver@asqki.com http://www.hoxserver.asqki.com
//
// Este programa es software libre; usted puede redistribuirlo y / o
// Modificarlo bajo los términos de la Licencia Pública General de GNU
// Publicada por la Free Software Foundation; ya sea la versión 2
// De la Licencia, o (a su elección) cualquier versión posterior .
//
// Este programa se distribuye con la esperanza de que sea útil,
// Pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de
// COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. ver el

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Hox
{
    public partial class ConfMongo : Form
    {
        public ConfMongo()
        {
            InitializeComponent();
            BtnGuardar.Click += new EventHandler(BtnGuardar_Click);
            BtnMongo.Click +=new EventHandler(BtnMongo_Click); 
            this.Load += new EventHandler(LeerRutas); 
        }
        private void BtnMongo_Click(object obejto, EventArgs e)
        {
            FolderBrowserDialog abrir = new FolderBrowserDialog();
            if (abrir.ShowDialog() == DialogResult.OK) {
                TextMongo.Text = abrir.SelectedPath;
            }
        }
        private void LeerRutas(object obejto, EventArgs e) {
            RutaDBMongo ruta = new RutaDBMongo(RutaDBMongo.OpcionRuta.Leer); 
            TextMongo.Text  =ruta.RutaDB; 
        }
        void BtnGuardar_Click(object sender, EventArgs e) {
           
                RutaDBMongo ruta = new RutaDBMongo(TextMongo.Text, RutaDBMongo.OpcionRuta.Escribir); 
                this.Close();
        }

     
    }
}
