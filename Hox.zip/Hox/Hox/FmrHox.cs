﻿
//Entorno de desarrollo para aplicaciones web Alternativa a Xampp, Wamp Appserv y demás, 
// Copyright (C ) Rodrigo Chambi Q, Email infohoxserver@asqki.com http://www.hoxserver.asqki.com
//
// Este programa es software libre; usted puede redistribuirlo y / o
// Modificarlo bajo los términos de la Licencia Pública General de GNU
// Publicada por la Free Software Foundation; ya sea la versión 2
// De la Licencia, o (a su elección) cualquier versión posterior .
//
// Este programa se distribuye con la esperanza de que sea útil,
// Pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de
// COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. ver el

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SatartStop;
using System.IO;
using System.Diagnostics;
using System.Threading;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.Devices ; 
using Microsoft.Win32;
using System.Security.Permissions;
//using Hox.ConectorSQL;    
namespace Hox
{
	[PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
    public partial class FmrHox : Form
    {
        public FmrHox()
        {
           
            InitializeComponent();
            VerficarYmostrar(); 
            BtnApache.Click += new EventHandler(BtnApache_Click);
            BtbMysql.Click += new EventHandler(BtbMysql_Click);
            BtnFil.Click += new EventHandler(BtnFil_Click);
            BtnMer.Click += new EventHandler(BtnMer_Click);
            BtnTomc.Click += new EventHandler(BtnTomc_Click); 
            BtbArg.Click += new EventHandler(BtbArg_Click);
            BtnPostGre.Click += new EventHandler(BtnPostGre_Click);
            BtbMon.Click += BtbMon_Click;
            Aplicacion.Iniciado += new AplicacionIniciado(Aplicacion_Iniciado);
            Aplicacion.Parado += new AplicaionParado(Aplicacion_Parado);  
             Timer_Actualizar.Tick += new EventHandler(Timer_Actualizar_Tick);
            Timer_Actualizar.Interval =7000; 
            //sector de los Items
             mySQLINIToolStripMenuItem.Click += new EventHandler(mySQLINIToolStripMenuItem_Click);
             phatToolStripMenuItem.Click += new EventHandler(phatToolStripMenuItem_Click);
             apacheconfToolStripMenuItem.Click += new EventHandler(apacheconfToolStripMenuItem_Click);
             phatToolStripMenuItem1.Click += new EventHandler(phatToolStripMenuItem1_Click);
             fileZillaServerInterfaceToolStripMenuItem.Click += new EventHandler(fileZillaServerInterfaceToolStripMenuItem_Click);
             fileZillaServerXMLToolStripMenuItem.Click += new EventHandler(fileZillaServerXMLToolStripMenuItem_Click);
             phatToolStripMenuItem2.Click += new EventHandler(phatToolStripMenuItem2_Click);
             MerStripMenuItem2.Click += new EventHandler(MerStripMenuItem2_Click);
             MerINIStripMenuItem3.Click += new EventHandler(MerINIStripMenuItem3_Click);
             ubiMerToolStripMenuItem.Click += new EventHandler(ubiMerToolStripMenuItem_Click);
             TomserverXMLToolStripMenuItem .Click += new EventHandler(tomcatToolStripMenuItem_Click);
             TomubicaciónToolStripMenuItem.Click += new EventHandler(TomubicaciónToolStripMenuItem_Click);
             pHPINIToolStripMenuItem.Click += new EventHandler(pHPINIToolStripMenuItem_Click);
             PHPubicaciónToolStripMenuItem1.Click += new EventHandler(PHPubicaciónToolStripMenuItem1_Click);
             httpwwwworlcomcomToolStripMenuItem.Click +=new EventHandler(VisitarSitioweb);
             INIPostgre.Click += new EventHandler(INIPostgre_Click);
             UbiPostgre.Click += new EventHandler(UbiPostgre_Click); 
           
            //sector eventos Botones
             BtnExplorador.Click += new EventHandler(BtnExplorador_Click);
             PHPbtn.Click += new EventHandler(PHPbtn_Click);
             PhMyAminbnt.Click += new EventHandler(PhMyAminbnt_Click);
             
            //intems
             ApacheWeb.Click += new EventHandler(ApacheWeb_Click);
             TomcatWeb.Click += new EventHandler(TomcatWeb_Click);
             ArgoSoftWeb.Click += new EventHandler(ArgoSoftWeb_Click);
            //ITEMS PHP
             ItemPhpPhat.Click += new EventHandler(ItemPhpPhat_Click);
             ItemPHPINI.Click += new EventHandler(ItemPHPINI_Click);
             ItemConVisualPHP.Click += new EventHandler(ItemConVisualPHP_Click);
             sobreEsteProgramaToolStripMenuItem.Click += new EventHandler(sobreEsteProgramaToolStripMenuItem_Click);
            this.Load += new EventHandler(FmrHox_Load);
           // CopiarDll();
            button3.Click +=PHPpgadmin;
            HostAlterToolStripMenuItem1.Click += new EventHandler(HostAlterToolStripMenuItem1_Click);
            httpwwwworlcomcomToolStripMenuItem.Click += new EventHandler(PaginaOficial); 
            RutaMogo.Click += new EventHandler(EstablecerRuta); 
            //sector de aplicaciones//
            mySQLToolStripMenuItem.Click += mySQLToolStripMenuItem_Click; 
            //
            rutaDeDBToolStripMenuItem.Click +=RutaMogoDb;
            ubicacionToolStripMenuItem.Click +=RutaMogoBs;
            versionDePHPToolStripMenuItem.Click +=new EventHandler(CambiarVersionphp);
            
            ChangePHP cargar=new ChangePHP();
            RutaPhpVersion= ChangePHP.PHPRuta;
        }
        
        private String RutaPhpVersion=string.Empty;
        
        private void CambiarVersionphp(object sender, EventArgs e){
        	ChangePHP Versionphp=new ChangePHP();
        	if(	Versionphp.ShowDialog()==DialogResult.OK){
        		BtnApache.PerformClick();
        	}
        }
        
        
        void VisitarSitioweb(object sender, EventArgs e){
         try {
        		
                Process.Start("http://www.hoxserver.asqki.com/");
            }
            catch (Exception exeption){

            }
        }
        
        void PHPpgadmin(object sender, EventArgs e){
        	 try {
        		
                Process.Start("http://localhost/phppgadmin/");
            }
            catch (Exception exeption){

            }
        
        }
        
        void RutaMogoDb(object sender, EventArgs e){
        	RutaDBMongo Ruta=new RutaDBMongo(RutaDBMongo.OpcionRuta.Leer);
            if (Directory.Exists(Ruta.RutaDB))
            {
                Ejecutar("explorer", Ruta.RutaDB);
            }
        }
        
        /// <summary>
        /// Abre la ruta de base de datos 
        /// MongoDB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void RutaMogoBs(object sender, EventArgs e){
        	String MysqlUbicacion = Application.StartupPath + @"\Programas\mongodb\";
            if (Directory.Exists(MysqlUbicacion))
            {
                Ejecutar("explorer", MysqlUbicacion);
            }
        }
        void mySQLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //InitFormSQL Nuevo = new InitFormSQL();
           // Nuevo.Show();  
        }
        /// <summary>
        /// Abre la ventana de configuracion
        /// de Base de datos  Mongo Y mysql
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EstablecerRuta(object sender, EventArgs e)
        {
            ConfMongo Abrir = new ConfMongo();
            Abrir.ShowDialog();
        }
        /// <summary>
        /// Direciona al sitio web oficial 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PaginaOficial(object sender, EventArgs e){
            try {
        		
                Process.Start("http://www.hoxserver.asqki.com/");
            }
            catch (Exception exeption){

            }
        }
 

        void HostAlterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            RutAlt Abrir = new RutAlt();
            Abrir.ShowDialog();  
        }

        void sobreEsteProgramaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Descripción ddd = new Descripción();
            ddd.ShowDialog();  
        }

        /// <summary>
        /// OBSOLETO funcionaba en la version anterior
        /// Copia al sistem 32  la libreria
        /// perteneciente a PHP
        /// libpq.dll
        /// </summary>
//        private void CopiarDll()
//        {
//            try
//            {
//              Computer Verfica = new Computer();
//              String Ruta1=Verfica.FileSystem.SpecialDirectories.ProgramFiles.Substring(0, 3)+@"WINDOWS\system32\";
//              String Ruta2 = Verfica.FileSystem.SpecialDirectories.ProgramFiles.Substring(0, 3) + @"WINDOWS\";
//              if (File.Exists(Ruta1 + "libpq.dll")) { }
//              else { 
//                  //Copia la libreria  corespondiente del PHP
//                  File.Copy(Application.StartupPath + @"\Programas\php\libpq.dll", Ruta1 + "libpq.dll", false);
//              }
//                //Compia la libreria corespondiente del PHP
//              if (File.Exists(Ruta2+ "libpq.dll")) { }
//              else{
//                  File.Copy(Application.StartupPath + @"\Programas\php\libpq.dll", Ruta2 + "libpq.dll", false);
//              }
//   
//            }
//            catch (Exception SS)
//            {
//                MessageBox.Show(SS.Message);  
//            }
//
//        }




        //Instanciacion de clases
       private  EjecutarAplicaiones Aplicacion = new EjecutarAplicaiones();
       private  System.Windows.Forms.Timer Timer_Actualizar = new System.Windows.Forms.Timer();
       private string NotePaMas = Application.StartupPath + @"\Programas\Notepad++\notepad++.exe";
       
       //permite almacenar valores de start y stop       
        private int 
        valorApache = 0,
        ValorMysql = 0, 
        ValorFileZilla = 0,
        ValorMercury = 0,
        ValorTomcat = 0,
        ValorArgosoftMail = 0,
        ValorPostgreSql = 0,
        ValorMongoDB = 0;
        #region "Eventos de Intems y botones"

        /// <summary>
        /// Btn Consola
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void BtnConsola_Click(object sender, EventArgs e)
        {
            
        }
        /// <summary>
        /// Llmada al programa gestionador  de base datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void BtnGestion_Click(object sender, EventArgs e){
        	
        }


        void PhMyAminbnt_Click(object sender, EventArgs e){
        	 try {
        		
                Process.Start("http://localhost/phpmyadmin/");
            }
            catch (Exception exeption){

            }
            
        }

        void PHPbtn_Click(object sender, EventArgs e)
        {
            OpcionPHP.Show(this, new System.Drawing.Point(PHPbtn.Location.X, (PHPbtn.Location.Y + PHPbtn.Size.Height - 1)));

           

        }
        /// <summary>
        /// Abre la ruta MYSQL
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ItemPhpPhat_Click(object sender, EventArgs e)
        {
            String MysqlUbicacion = RutaPhpVersion;
            if (Directory.Exists(MysqlUbicacion))
            {
                Ejecutar("explorer", MysqlUbicacion);
            }
        }


        void ItemPHPINI_Click(object sender, EventArgs e){
            String Archivo =RutaPhpVersion + @"\php.ini";
            if (File.Exists(NotePaMas)){
                Ejecutar(NotePaMas, Archivo);
            }
            else{
                Ejecutar("notepad", Archivo);
            }
        }

        void ItemConVisualPHP_Click(object sender, EventArgs e)
        {
            FmerConfPHP Formualrio = new FmerConfPHP();
            Formualrio.ShowDialog();  
        }


        void INIPostgre_Click(object sender, EventArgs e)
        {
            String Archivo = Application.StartupPath + @"\Programas\PostGreSQL\data\postgresql.conf";


            if (File.Exists(NotePaMas))
            {
                Ejecutar(NotePaMas, Archivo);
            }
            else
            {
                Ejecutar("notepad", Archivo);
            }
        }

        void UbiPostgre_Click(object sender, EventArgs e)
        {
            String MysqlUbicacion = Application.StartupPath + @"\Programas\PostGreSQL\";
            if (Directory.Exists(MysqlUbicacion))
            {
                Ejecutar("explorer", MysqlUbicacion);
            }
        }


        void ArgoSoftWeb_Click(object sender, EventArgs e){
             try {
        		
                Process.Start("http://localhost:88/");
            }
            catch (Exception exeption){

            }
        }

        void TomcatWeb_Click(object sender, EventArgs e) {
              try {
        		
                Process.Start("http://localhost:8080/");
            }
            catch (Exception exeption){

            }
        }

        void ApacheWeb_Click(object sender, EventArgs e){
            //Process.Start("http://localhost:80/");
             try {
        		
                Process.Start("http://localhost:80/");
            }
            catch (Exception exeption){

            }
        }

        void BtnExplorador_Click(object sender, EventArgs e){
            OpcionNavegacion.Show(this, new System.Drawing.Point(BtnExplorador.Location.X, (BtnExplorador.Location.Y + BtnExplorador.Size.Height - 1)));
        }



        void mySQLINIToolStripMenuItem_Click(object sender, EventArgs e){
            String MysqlINI = Application.StartupPath + @"\Programas\mysql\bin\my.ini";


            if (File.Exists(NotePaMas))
            {
                Ejecutar(NotePaMas, MysqlINI);
            }
            else
            {
                Ejecutar("notepad", MysqlINI);
            }


        }
        void phatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String MysqlUbicacion = Application.StartupPath + @"\Programas\mysql\";
            if (Directory.Exists(MysqlUbicacion))
            {
                Ejecutar("explorer", MysqlUbicacion);
            }
        }


        void phatToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            String Ubicacion = Application.StartupPath + @"\Programas\apache\";
            if (Directory.Exists(Ubicacion))
            {
                Ejecutar("explorer", Ubicacion);
            }
        }

        void apacheconfToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String ApacheConf = Application.StartupPath + @"\Programas\apache\conf\httpd.conf";


            if (File.Exists(NotePaMas))
            {
                Ejecutar(NotePaMas, ApacheConf);
            }
            else
            {
                Ejecutar("notepad", ApacheConf);
            }
        }
        void fileZillaServerInterfaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String Ubicacion = Application.StartupPath + @"\Programas\FileZillaFTP\FileZilla Server Interface.exe";
            if (File.Exists(Ubicacion))
            {
                Ejecutar(Ubicacion, "");
            }
        }
        void fileZillaServerXMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String Archivo = Application.StartupPath + @"\Programas\FileZillaFTP\FileZilla Server Interface.xml";
            if (File.Exists(NotePaMas)){
                Ejecutar(NotePaMas, Archivo);
            }
            else{
                Ejecutar("notepad", Archivo);
            }
        }

        void phatToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            String Ubicacion = Application.StartupPath + @"\Programas\FileZillaFTP\";
            if (Directory.Exists(Ubicacion))
            {
                Ejecutar("explorer", Ubicacion);
            }
        }
        void pHPINIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String Archivo = Application.StartupPath + @"\Programas\php\php.ini";


            if (File.Exists(NotePaMas))
            {
                Ejecutar(NotePaMas, Archivo);
            }
            else
            {
                Ejecutar("notepad", Archivo);
            }
        }

        void PHPubicaciónToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            String MysqlUbicacion = RutaPhpVersion;
            if (Directory.Exists(MysqlUbicacion))
            {
                Ejecutar("explorer", MysqlUbicacion);
            }
        }
        private void Ejecutar(String Aplicacion, String Argumento){
            try{
                Process Iniciar = new Process();
                Iniciar.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
                Iniciar.StartInfo.FileName = Aplicacion;
                //Iniciar.StartInfo.UseShellExecute =true;
               Iniciar.StartInfo.Verb = "runas";
                Iniciar.StartInfo.Arguments = Argumento;
                Iniciar.Start();
            }
            catch (Exception Exempcion) { 
        	  MessageBox.Show (Exempcion.Message.ToString ());
            }
        }
        #endregion
        InfoProgramas Progrmas = new InfoProgramas();
            
        void Timer_Actualizar_Tick(object sender, EventArgs e)
        {
            Application.DoEvents();  
            Progrmas.Escribir();   
           Buscar();//genera problemas a la hora de iniciar o parar
            //HoxHost.Text ="http://localhost/"+ RutAlt.Alias;
            //jQUIRYToolStripMenuItem.Text = "http://" + RutAlt.VirtualHost;   
           
        }
      /// <summary>
      /// registrando configuracion de argosoft
      /// </summary>
        private void VerficarYmostrar()
        {
            
            //registrando datos de argosoft

            RegistryKey Valors = Registry.CurrentUser.OpenSubKey(@"Software\ArGoSoft\Mail Server\Setup");
            if (Valors == null)
            {
                RegistryKey Valor = Registry.CurrentUser.CreateSubKey(@"Software\ArGoSoft\Mail Server\Setup");
                Valor.SetValue("Allow relay", 0, RegistryValueKind.String);
                Valor.SetValue("Authenticate Lists", 0, RegistryValueKind.String);
                Valor.SetValue("Auto Response Delay", 0, RegistryValueKind.String);
                Valor.SetValue("Auto Start", "1", RegistryValueKind.String);
                Valor.SetValue("Disable new MIME", "0", RegistryValueKind.String);
                Valor.SetValue("DNS Server", "", RegistryValueKind.String);
                Valor.SetValue("Hide Passwords", 0, RegistryValueKind.String);
                Valor.SetValue("Local Domains", "localhost.com,gmail.com", RegistryValueKind.String);
                Valor.SetValue("Local Host", "", RegistryValueKind.String);
                Valor.SetValue("Log Exchangers", 0, RegistryValueKind.String);
                Valor.SetValue("Log POP commands", 0, RegistryValueKind.String);
                Valor.SetValue("Log SMTP commands", 0, RegistryValueKind.String);
                Valor.SetValue("Log to File", 1, RegistryValueKind.String);
                Valor.SetValue("Log Web commands", 0, RegistryValueKind.String);
                Valor.SetValue("Message Size Limit", 0, RegistryValueKind.String);
                Valor.SetValue("Not Authenticated IP", 0, RegistryValueKind.String);
                Valor.SetValue("Program Path", Application.StartupPath + @"\ArgosoftMail\", RegistryValueKind.String);
                Valor.SetValue("Relay Timeout", 20, RegistryValueKind.String);
                Valor.SetValue("SMTP - Same as POP", 0, RegistryValueKind.String);
                Valor.SetValue("SMTP Authentication", 0, RegistryValueKind.String);
                Valor.SetValue("SMTP Password", "", RegistryValueKind.String);
                Valor.SetValue("SMTP Port", 25, RegistryValueKind.String);
                Valor.SetValue("SMTP User Name", "", RegistryValueKind.String);
                Valor.SetValue("Web Port", 88, RegistryValueKind.String);
                Valor.Close();  
            }
            else {
               
            
            }    

            //verifcar  programas ejecudatos
            
        }

        /// <summary>
        /// Al iniciar el programa
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void FmrHox_Load(object sender, EventArgs e)
        {
            Timer_Actualizar.Enabled = true;
            Progrmas.Escribir();
            Buscar();
        }

        

        void Explorador_Click(object sender, EventArgs e)
        {

            //String Phat = Application.StartupPath + @"\ArgosoftMail\mailserver.exe";
            //ProcessStartInfo Procesar = new ProcessStartInfo(Phat );
 
              
            //FileInfo InformacionArc = new FileInfo(Phat); 
            //Procesar.FileName = InformacionArc.FullName;
         //  Procesar.Arguments ="dir" ; 
             
            //Procesar.WindowStyle = ProcessWindowStyle.Minimized ;
           // Process se = Process.Start(Procesar);
            //Thread.Sleep(5000);  
         
            
            

        }

        void Aplicacion_Parado(object objeto, string[] Nombre)
        {
        	listView1.BeginUpdate();

            switch (Nombre[4])
            {
                case "httpd":
                    BtnApache.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[0].ForeColor = Color.Red;
                    listView1.Items[0].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[0].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[0].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[0].SubItems[3].Text = Nombre[3].ToString();
                    valorApache = Int32.Parse(Nombre[5].ToString());//Rescata valor 1 si es que se ha iniciado por lo contrario 0  
                    break;
                case "Tomcat":
                    BtnTomc.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[1].ForeColor = Color.Red; 
                    listView1.Items[1].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[1].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[1].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[1].SubItems[3].Text = Nombre[3].ToString();
                    ValorTomcat = Int32.Parse(Nombre[5].ToString());
                    break;
                case "mysqld":
                    BtbMysql.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[2].ForeColor = Color.Red;
                    listView1.Items[2].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[2].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[2].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[2].SubItems[3].Text = Nombre[3].ToString();
                    ValorMysql  = Int32.Parse(Nombre[5].ToString());//Rescata valor 1 si es que se ha iniciado por lo contrario 0 
                    break;
                case "mongod":
                    BtbMon .Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[3].ForeColor = Color.Red;
                    listView1.Items[3].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[3].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[3].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[3].SubItems[3].Text = Nombre[3].ToString();
                    ValorMongoDB = Int32.Parse(Nombre[5].ToString());
                    break;
                case "PostgreSQL":
                    BtnPostGre.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[4].ForeColor = Color.Red;  
                    listView1.Items[4].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[4].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[4].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[4].SubItems[3].Text = Nombre[3].ToString();
                    ValorPostgreSql = Int32.Parse(Nombre[5].ToString());
                    break;
                case "FileZilla":
                    BtnFil  .Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[5].ForeColor = Color.Red;
                    listView1.Items[5].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[5].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[5].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[5].SubItems[3].Text = Nombre[3].ToString();
                    ValorFileZilla  = Int32.Parse(Nombre[5].ToString());
                    break;
                case "Mercury":
                    BtnMer  .Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[6].ForeColor = Color.Red;
                    listView1.Items[6].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[6].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[6].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[6].SubItems[3].Text = Nombre[3].ToString();
                    ValorMercury = Int32.Parse(Nombre[5].ToString());
                    break;
                    
                case "ArgoSoftMail":
                    BtbArg.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[7].ForeColor = Color.Red;
                    listView1.Items[7].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[7].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[7].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[7].SubItems[3].Text = Nombre[3].ToString();
                    ValorArgosoftMail = Int32.Parse(Nombre[5].ToString());
                    break;

            }
            listView1.EndUpdate();
        }
        /// <summary>
        /// Evento actualizador  
        /// </summary>
        /// <param name="objeto"></param>
        /// <param name="Nombre"></param>
        void Aplicacion_Iniciado(object objeto, string[] Nombre)
        {

        	listView1.BeginUpdate();
            switch (Nombre[4])
            {
                case "httpd":
                    BtnApache.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[0].ForeColor = Color.Black   ;  

                    listView1.Items[0].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[0].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[0].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[0].SubItems[3].Text = Nombre[3].ToString();
                    valorApache = Int32.Parse(Nombre[5].ToString());//Rescata valor 1 si es que se ha iniciado por lo contrario 0  
                    break;
                case "Tomcat":
                    BtnTomc.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[1].ForeColor = Color.Black   ;  
                    listView1.Items[1].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[1].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[1].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[1].SubItems[3].Text = Nombre[3].ToString();
                    ValorTomcat = Int32.Parse(Nombre[5].ToString());
                    break;
                case "mysqld":
                    BtbMysql.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[2].ForeColor = Color.Black;  
                    listView1.Items[2].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[2].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[2].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[2].SubItems[3].Text = Nombre[3].ToString();
                     ValorMysql  = Int32.Parse(Nombre[5].ToString());//Rescata valor 1 si es que se ha iniciado por lo contrario 0
                    break;
                case "mongod":
                   
                    BtbMon.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[3].ForeColor = Color.Black;  
                    listView1.Items[3].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[3].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[3].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[3].SubItems[3].Text = Nombre[3].ToString();
                    ValorMongoDB = Int32.Parse(Nombre[5].ToString());
                    break;
                case "PostgreSQL":
                    BtnPostGre.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[4].ForeColor = Color.Black;  
                    listView1.Items[4].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[4].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[4].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[4].SubItems[3].Text = Nombre[3].ToString();
                    ValorPostgreSql = Int32.Parse(Nombre[5].ToString());
                    break;
                case "FileZilla":
                     BtnFil.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[5].ForeColor = Color.Black;  
                    listView1.Items[5].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[5].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[5].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[5].SubItems[3].Text = Nombre[3].ToString();
                    ValorFileZilla = Int32.Parse(Nombre[5].ToString());
                    break;
                case "Mercury":
                    BtnMer.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[6].ForeColor = Color.Black;
                    listView1.Items[6].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[6].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[6].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[6].SubItems[3].Text = Nombre[3].ToString();
                    ValorMercury = Int32.Parse(Nombre[5].ToString());
                    break;
                case "ArgoSoftMail":
                    BtbArg.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[7].ForeColor = Color.Black;
                    listView1.Items[7].SubItems[0].Text = Nombre[0].ToString();
                    listView1.Items[7].SubItems[1].Text = Nombre[1].ToString();
                    listView1.Items[7].SubItems[2].Text = Nombre[2].ToString();
                    listView1.Items[7].SubItems[3].Text = Nombre[3].ToString();
                    ValorArgosoftMail = Int32.Parse(Nombre[5].ToString());
                    break;

            }
    

            //Intems.Text = 
            //Intems.SubItems.Add(Nombre[1].ToString());
            //Intems.SubItems.Add(Nombre[2].ToString());
            //Intems.SubItems.Add(Nombre[3].ToString());
            //listView1.Items.Add(Intems);  
           listView1.EndUpdate();            
        }
      
        /// <summary>
        /// Ejecucion del Apache
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void BtnApache_Click(object sender, EventArgs e){
            String Phat = Application.StartupPath + @"\Programas\apache\bin\httpd.exe";
            string Nombre_Recuperado = "";
            FileInfo InformacionArc = new FileInfo(Phat);
            Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del ejecutable
            // Aplicacion.Iniciar(Phat);
            Thread.Sleep(1000);
             if (valorApache == 0){
                 Aplicacion.Iniciar(Phat);
             }
             else {
                 Aplicacion.Parar(Nombre_Recuperado, close.noting);
                 //valorApache = 0;
                 //BtnApache.Image = Hox.Properties.Resources.Player_stop;
                 //listView1.Items[0].ForeColor = Color.Red;
                 //listView1.Items[0].SubItems[3].Text = "Parado";
             }   
        }
        /// <summary>
        /// Ejecucion del Mysql
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void BtbMysql_Click(object sender, EventArgs e){

            String Phat = Application.StartupPath + @"\Programas\mysql\bin\mysqld.exe";
            string Nombre_Recuperado = "";
            FileInfo InformacionArc = new FileInfo(Phat);
            Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del ejecutable
            Thread.Sleep(1000);
            if (ValorMysql == 0)
            {
                Aplicacion.Iniciar(Phat);
            }
            else
            {
                Aplicacion.Parar(Nombre_Recuperado, close.noting);

            }
  
        }

        void BtnFil_Click(object sender, EventArgs e)
        {
            String Phat = Application.StartupPath + @"\Programas\FileZillaFTP\FileZilla Server.exe";
            string Nombre_Recuperado = "";
            FileInfo InformacionArc = new FileInfo(Phat);
            Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del ejecutable
            Thread.Sleep(1000);
            if (ValorFileZilla  == 0)
            {
                Aplicacion.Iniciar(Phat);

            }
            else
            {
              Aplicacion.Parar(Nombre_Recuperado,close.noting);
               
            }

        }

        void MerStripMenuItem2_Click(object sender, EventArgs e)
        {
            String Ubicacion = Application.StartupPath + @"\Programas\MercuryMail\mercury.exe";
            if (File.Exists(Ubicacion))
            {
                Ejecutar(Ubicacion, "");
            }
        }


        void MerINIStripMenuItem3_Click(object sender, EventArgs e)
        {
            String Archivo = Application.StartupPath + @"\Programas\MercuryMail\mercury.ini";


            if (File.Exists(NotePaMas))
            {
                Ejecutar(NotePaMas, Archivo);
            }
            else
            {
                Ejecutar("notepad", Archivo);
            }
        }
        void ubiMerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String MysqlUbicacion = Application.StartupPath + @"\Programas\MercuryMail\";
            if (Directory.Exists(MysqlUbicacion))
            {
                Ejecutar("explorer", MysqlUbicacion);
            }
        }

        private void tomcatToolStripMenuItem_Click(object objet, EventArgs e)
        {
            String Archivo = Application.StartupPath + @"\Programas\tomcat\conf\server.xml";


            if (File.Exists(NotePaMas))
            {
                Ejecutar(NotePaMas, Archivo);
            }
            else
            {
                Ejecutar("notepad", Archivo);
            }
        }

        void TomubicaciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String Ubicacion = Application.StartupPath + @"\Programas\tomcat\";
            if (Directory.Exists(Ubicacion))
            {
                Ejecutar("explorer", Ubicacion);
            }

        }

        //Boton evento que inica el Mongo DB
        void BtbMon_Click(object sender, EventArgs e){
            String Phat = Application.StartupPath + @"\Programas\mongodb\bin\mongod.exe";
            string Nombre_Recuperado = "";
            FileInfo InformacionArc = new FileInfo(Phat);
            Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del ejecutable
            Thread.Sleep(1000);
            if (ValorMongoDB == 0)
            {
                Aplicacion.Iniciar(Phat);

            }
            else
            {
               Aplicacion.Parar(Nombre_Recuperado,close.window );
   
            }

        }
       //Boton que inicia el proceso Mercury Mail
        void BtnMer_Click(object sender, EventArgs e)
        {
            String Phat = Application.StartupPath + @"\Programas\MercuryMail\mercury.exe";
            string Nombre_Recuperado = "";
            FileInfo InformacionArc = new FileInfo(Phat);
            Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del ejecutable
            Thread.Sleep(1000);
            if (ValorMercury  == 0)
            {
                Aplicacion.Iniciar(Phat);
               
            }
            else
            {
               Aplicacion.Parar(Nombre_Recuperado,close.noting);
                
            }
        }

        void BtbArg_Click(object sender, EventArgs e)
        {
            String Phat = Application.StartupPath + @"\Programas\ArgosoftMail\mailserver.exe";
            string Nombre_Recuperado = "";
            FileInfo InformacionArc = new FileInfo(Phat);
            Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del ejecutable
            Thread.Sleep(1000);
            if (ValorArgosoftMail  == 0)
            {
                Aplicacion.Iniciar(Phat);
  
            }
            else
            {
               Aplicacion.Parar(Nombre_Recuperado,close.noting );
   
            }
        }

        void BtnTomc_Click(object sender, EventArgs e)
        {

            String Phat = Application.StartupPath + @"\Programas\tomcat\catalina_start.bat";
            string Nombre_Recuperado = "";
            FileInfo InformacionArc = new FileInfo(Phat);
            Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del bat
            if (ValorTomcat == 0)
            {
                Aplicacion.Iniciar(Phat);

            }
            else
            {
              Aplicacion.Parar("java",close.noting);
            }
        }
        void BtnPostGre_Click(object sender, EventArgs e)
        {
            String Phat = Application.StartupPath + @"\Programas\PostGreSQL\bin\pg_ctl.exe";
            string Nombre_Recuperado = "";
            FileInfo InformacionArc = new FileInfo(Phat);
            Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del bat
            if (ValorPostgreSql == 0)
            {
                Aplicacion.Iniciar(Phat);
            }
            else
            {
                Aplicacion.Parar("postgres", close.noting);

            }
        }
         
        /// <summary>
        /// Determina si es que existe el determinado proceso
        /// </summary>
        /// <param name="nombre"></param>
        /// <returns></returns>
         private String[] IsexistProcess(string nombre) {
        	String[] lista ;
            Process[] numbers = Process.GetProcesses();
            var ListProces =
                from n in numbers
                where n.ProcessName == nombre
                select n;
            bool exist = ListProces.Any();
            try {
            numbers=  Process.GetProcessesByName(nombre);
            lista = new string[]  { exist.ToString(), numbers[0].Id.ToString() };
            }catch( Exception e){
            lista = new string[] { exist.ToString(), "0"};
            }
            
            return lista;
        }
        
        //se ha areglado le bug al iniciar y parar de la interfaz de usuario
        LeerPuerto Puerto=new LeerPuerto();//lee los puestos de las apliciones 
        private void Buscar()
        {
        	
        	
        	
            Application.DoEvents();
            listView1.BeginUpdate();
            
            if (IsexistProcess( "httpd")[0]=="True"){
                    valorApache = 1;
                    BtnApache.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[0].ForeColor = Color.Black;
                    listView1.Items[0].SubItems[0].Text = "Apache";
                    listView1.Items[0].SubItems[1].Text = IsexistProcess( "httpd")[1].ToString();
                    Puerto.LeerConfigApache();
                    listView1.Items[0].SubItems[2].Text = Puerto.PrtApache.Trim();
                    listView1.Items[0].SubItems[3].Text = "Iniciado";    
                }else{
                    valorApache = 0;
                    BtnApache.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[0].ForeColor = Color.Red;
                    listView1.Items[0].SubItems[0].Text = "Apache";
                    listView1.Items[0].SubItems[1].Text = "0";
                    Puerto.LeerConfigApache();
                    listView1.Items[0].SubItems[2].Text = Puerto.PrtApache.Trim();
                    listView1.Items[0].SubItems[3].Text = "Parado";
                }
            if (IsexistProcess( "mysqld")[0]=="True"){
                    ValorMysql = 1;
                    BtbMysql.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[2].ForeColor = Color.Black;
                    listView1.Items[2].SubItems[0].Text = "Mysql";
                    listView1.Items[2].SubItems[1].Text = IsexistProcess( "mysqld")[1].ToString();
                    Puerto.LeerIniMysql();
                    listView1.Items[2].SubItems[2].Text = Puerto.PrtMySQL.Trim();
                    listView1.Items[2].SubItems[3].Text = "Iniciado";
            }else{
                    ValorMysql = 0;
                    BtbMysql.Image =Hox.Properties.Resources.Player_stop;
                    listView1.Items[2].ForeColor = Color.Red;
                    listView1.Items[2].SubItems[0].Text = "Mysql";
                    listView1.Items[2].SubItems[1].Text = "0";
                    Puerto.LeerIniMysql();
                    listView1.Items[2].SubItems[2].Text = Puerto.PrtMySQL.Trim();
                    listView1.Items[2].SubItems[3].Text = "Parado";
            }
            if (IsexistProcess( "mongod")[0]=="True"){
            	    ValorMongoDB=1;
                    BtbMon.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[3].ForeColor = Color.Black;
                    listView1.Items[3].SubItems[0].Text = "Mongod";
                    listView1.Items[3].SubItems[1].Text = IsexistProcess( "mongod")[1].ToString();
                    listView1.Items[3].SubItems[2].Text = Puerto.PrtMongoDB.Trim();
                    listView1.Items[3].SubItems[3].Text = "Iniciado";
            }else{
            	    ValorMongoDB = 0;
                    BtbMon.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[3].ForeColor = Color.Red;
                    listView1.Items[3].SubItems[0].Text = "Mongod";
                    listView1.Items[3].SubItems[1].Text = "0";
                    listView1.Items[3].SubItems[2].Text = Puerto.PrtMongoDB.Trim();
                    listView1.Items[3].SubItems[3].Text = "Parado";
            }
            if (IsexistProcess("FileZilla Server")[0] == "True")
                {
                    ValorFileZilla = 1;
                    BtnFil.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[5].ForeColor = Color.Black;
                    listView1.Items[5].SubItems[0].Text = "FileZilla";
                    listView1.Items[5].SubItems[1].Text = IsexistProcess("FileZilla Server")[1].ToString();
                    Puerto.LeerFilezilla();
                    listView1.Items[5].SubItems[2].Text = Puerto.PrtFiliZilla.Trim();
                    listView1.Items[5].SubItems[3].Text = "Iniciado";
                }else{
                     ValorFileZilla = 0;
                    BtnFil.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[5].ForeColor = Color.Red;
                    listView1.Items[5].SubItems[0].Text = "FileZilla";
                    listView1.Items[5].SubItems[1].Text = "0";
                    Puerto.LeerFilezilla();
                    listView1.Items[5].SubItems[2].Text = Puerto.PrtFiliZilla.Trim();
                    listView1.Items[5].SubItems[3].Text = "Parado";
                }
            if (IsexistProcess("mercury")[0]  == "True"){
                    ValorMercury = 1;
                    BtnMer.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[6].ForeColor = Color.Black;
                    listView1.Items[6].SubItems[0].Text = "Mercury";
                    listView1.Items[6].SubItems[1].Text = IsexistProcess("mercury")[1] .ToString();
                    Puerto.LeerMercury();
                    listView1.Items[6].SubItems[2].Text = Puerto.PrtMercury.Trim();
                    listView1.Items[6].SubItems[3].Text = "Iniciado";
            }else{
            	    ValorMercury = 0;
                    BtnMer.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[6].ForeColor = Color.Red;
                    listView1.Items[6].SubItems[0].Text = "Mercury";
                    listView1.Items[6].SubItems[1].Text = "0";
                    Puerto.LeerMercury();
                    listView1.Items[6].SubItems[2].Text = Puerto.PrtMercury.Trim();
                    listView1.Items[6].SubItems[3].Text = "Parado";
            }
                if (IsexistProcess("mailserver")[0]  == "True"){
            	    ValorArgosoftMail = 1;
                    BtbArg.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[7].ForeColor = Color.Black;
                    listView1.Items[7].SubItems[0].Text = "ArgoSoftMail";
                    listView1.Items[7].SubItems[1].Text = IsexistProcess("mailserver")[1].ToString();
                    Puerto.LeerArgosoft();
                    listView1.Items[7].SubItems[2].Text = Puerto.PrtArgosoft.Trim();
                    listView1.Items[7].SubItems[3].Text = "Iniciado"; 
                }else{
                    ValorArgosoftMail = 0;
                    BtbArg.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[7].ForeColor = Color.Red;
                    listView1.Items[7].SubItems[0].Text = "ArgoSoftMail";
                    listView1.Items[7].SubItems[1].Text = "0";
                    Puerto.LeerArgosoft();
                    listView1.Items[7].SubItems[2].Text = Puerto.PrtArgosoft.Trim();
                    listView1.Items[7].SubItems[3].Text = "Parado";
                   
              }
            if (IsexistProcess("java")[0]== "True")
                {
                    ValorTomcat = 1;
                    BtnTomc.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[1].ForeColor = Color.Black;
                    listView1.Items[1].SubItems[0].Text = "Tomcat";
                    listView1.Items[1].SubItems[1].Text = IsexistProcess("java")[1].ToString();
                    Puerto.LeerTomcat();
                    listView1.Items[1].SubItems[2].Text = Puerto.PrtTomcat.Trim();
                    listView1.Items[1].SubItems[3].Text = "Iniciado";
            }else{
                    ValorTomcat = 0;
                    BtnTomc.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[1].ForeColor = Color.Red;
                    listView1.Items[1].SubItems[0].Text = "Tomcat";
                    listView1.Items[1].SubItems[1].Text = "0";
                    Puerto.LeerTomcat();
                    listView1.Items[1].SubItems[2].Text = Puerto.PrtTomcat.Trim();
                    listView1.Items[1].SubItems[3].Text = "Parado";
            }
            if (IsexistProcess("postgres")[0] == "True") {
                    ValorPostgreSql = 1;
                    BtnPostGre.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[4].ForeColor = Color.Black;
                    listView1.Items[4].SubItems[0].Text = "PostgreSQL";
                    listView1.Items[4].SubItems[1].Text = IsexistProcess("postgres")[1].ToString();
                    Puerto.LeerPostgreSQL();
                    listView1.Items[4].SubItems[2].Text = Puerto.PrtPostgreSQL.Trim();
                    listView1.Items[4].SubItems[3].Text = "Iniciado";

            }else{
                    ValorPostgreSql = 0;
                    BtnPostGre.Image = Hox.Properties.Resources.Player_stop;
                    listView1.Items[4].ForeColor = Color.Red;
                    listView1.Items[4].SubItems[0].Text = "PostgreSQL";
                    listView1.Items[4].SubItems[1].Text = "0";
                    Puerto.LeerPostgreSQL();
                    listView1.Items[4].SubItems[2].Text = Puerto.PrtPostgreSQL.Trim();
                    listView1.Items[4].SubItems[3].Text = "Parado";
            }
            listView1.EndUpdate();
            /*foreach (Process list in Process.GetProcesses()){
                if (list.ProcessName == "httpd"){
                    valorApache = 1;
                    BtnApache.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[0].ForeColor = Color.Black;
                    listView1.Items[0].SubItems[0].Text = "Apache";
                    listView1.Items[0].SubItems[1].Text = list.Id.ToString();
                    Puerto.LeerConfigApache();
                    listView1.Items[0].SubItems[2].Text = Puerto.PrtApache;
                    listView1.Items[0].SubItems[3].Text = "Iniciado";
                    //MessageBox.Show("is");  
                }
            	
                //else
                //{
                //    valorApache = 0;
                //    BtnApache.Image = Hox.Properties.Resources.Player_stop;
                //    listView1.Items[0].ForeColor = Color.Red;
                //    listView1.Items[0].SubItems[0].Text = "Apache";
                //    listView1.Items[0].SubItems[1].Text = "0";
                //    Puerto.LeerConfigApache();
                //    listView1.Items[0].SubItems[2].Text = Puerto.PrtApache;
                //    listView1.Items[0].SubItems[3].Text = "Parado";

                //}

                if (list.ProcessName == "mysqld")
                {
                    ValorMysql = 1;
                    BtbMysql.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[2].ForeColor = Color.Black;
                    listView1.Items[2].SubItems[0].Text = "Mysql";
                    listView1.Items[2].SubItems[1].Text = list.Id.ToString();
                    Puerto.LeerIniMysql();
                    listView1.Items[2].SubItems[2].Text = Puerto.PrtMySQL;
                    listView1.Items[2].SubItems[3].Text = "Iniciado";
                }
                if (list.ProcessName == "mongod")
                {
                    valorApache = 1;
                    BtbMon.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[3].ForeColor = Color.Black;
                    listView1.Items[3].SubItems[0].Text = "Mongod";
                    listView1.Items[3].SubItems[1].Text = list.Id.ToString();

                    listView1.Items[3].SubItems[2].Text = Puerto.PrtMongoDB;
                    listView1.Items[3].SubItems[3].Text = "Iniciado";
                    //MessageBox.Show("is");  
                }
                //else {
                //ValorMysql  = 0;
                //    BtbMysql.Image = Hox.Properties.Resources.Player_stop;
                //    listView1.Items[1].ForeColor = Color.Red; 
                //    listView1.Items[1].SubItems[0].Text="MySQL"; 
                //    listView1.Items[1].SubItems[1].Text = "0";
                //    Puerto.LeerIniMysql  ();  
                //    listView1.Items[1].SubItems[2].Text = Puerto.PrtMySQL   ;
                //    listView1.Items[1].SubItems[3].Text = "Parado";

                //}

                if (list.ProcessName == "FileZilla Server")
                {
                    ValorFileZilla = 1;
                    BtnFil.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[5].ForeColor = Color.Black;
                    listView1.Items[5].SubItems[0].Text = "FileZilla";
                    listView1.Items[5].SubItems[1].Text = list.Id.ToString();
                    Puerto.LeerFilezilla();
                    listView1.Items[5].SubItems[2].Text = Puerto.PrtFiliZilla;
                    listView1.Items[5].SubItems[3].Text = "Iniciado";
                }
                //else {
                //    ValorMysql  = 0;
                //    BtnFil.Image = Hox.Properties.Resources.Player_stop;
                //    listView1.Items[2].ForeColor = Color.Red; 
                //    listView1.Items[2].SubItems[0].Text="FileZilla"; 
                //    listView1.Items[2].SubItems[1].Text = "0";
                //    Puerto.LeerFilezilla  ();  
                //    listView1.Items[2].SubItems[2].Text = Puerto.PrtFiliZilla;
                //    listView1.Items[2].SubItems[3].Text = "Parado";
                //}


                if (list.ProcessName == "mercury")
                {
                    ValorMercury = 1;
                    BtnMer.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[6].ForeColor = Color.Black;
                    listView1.Items[6].SubItems[0].Text = "Mercury";
                    listView1.Items[6].SubItems[1].Text = list.Id.ToString();
                    Puerto.LeerMercury();
                    listView1.Items[6].SubItems[2].Text = Puerto.PrtMercury;
                    listView1.Items[6].SubItems[3].Text = "Iniciado";
                }
                //else {
                // ValorMercury  = 0;
                //    BtnMer.Image = Hox.Properties.Resources.Player_stop;
                //    listView1.Items[3].ForeColor = Color.Red; 
                //    listView1.Items[3].SubItems[0].Text="Mercury"; 
                //    listView1.Items[3].SubItems[1].Text = "0";
                //    Puerto.LeerMercury  ();  
                //    listView1.Items[3].SubItems[2].Text = Puerto.PrtMercury;
                //    listView1.Items[3].SubItems[3].Text = "Parado";
                //}

                if (list.ProcessName == "mailserver")
                {
                    
                    BtbArg.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[7].ForeColor = Color.Black;
                    listView1.Items[7].SubItems[0].Text = "ArgoSoftMail";
                    listView1.Items[7].SubItems[1].Text = list.Id.ToString();
                    Puerto.LeerArgosoft();
                    listView1.Items[7].SubItems[2].Text = Puerto.PrtArgosoft;
                    listView1.Items[7].SubItems[3].Text = "Iniciado";
                    ValorArgosoftMail = 1;
                }
                //else {
                // ValorArgosoftMail  = 0;
                //    BtbArg.Image = Hox.Properties.Resources.Player_stop;
                //    listView1.Items[4].ForeColor = Color.Red; 
                //    listView1.Items[4].SubItems[0].Text="ArgoSoftMail"; 
                //    listView1.Items[4].SubItems[1].Text = "0";
                //    Puerto.LeerArgosoft  ();  
                //    listView1.Items[4].SubItems[2].Text = Puerto.PrtArgosoft;
                //    listView1.Items[4].SubItems[3].Text = "Parado";
                //}

                if (list.ProcessName == "java")
                {
                    ValorTomcat = 1;
                    BtnTomc.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[1].ForeColor = Color.Black;
                    listView1.Items[1].SubItems[0].Text = "Tomcat";
                    listView1.Items[1].SubItems[1].Text = list.Id.ToString();
                    Puerto.LeerTomcat();
                    listView1.Items[1].SubItems[2].Text = Puerto.PrtTomcat;
                    listView1.Items[1].SubItems[3].Text = "Iniciado";
                }

                if (list.ProcessName == "postgres")
                {
                    ValorPostgreSql = 1;
                    BtnPostGre.Image = Hox.Properties.Resources.Player_play;
                    listView1.Items[4].ForeColor = Color.Black;
                    listView1.Items[4].SubItems[0].Text = "PostgreSQL";
                    listView1.Items[4].SubItems[1].Text = list.Id.ToString();
                    Puerto.LeerPostgreSQL();
                    listView1.Items[4].SubItems[2].Text = Puerto.PrtPostgreSQL;
                    listView1.Items[4].SubItems[3].Text = "Iniciado";

                }

                //else {
                // ValorTomcat  = 0;
                //    BtnTomc.Image = Hox.Properties.Resources.Player_stop;
                //    listView1.Items[5].ForeColor = Color.Red; 
                //    listView1.Items[5].SubItems[0].Text="Tomcat"; 
                //    listView1.Items[5].SubItems[1].Text = "0";
                //    Puerto.LeerTomcat  ();  
                //    listView1.Items[5].SubItems[2].Text = Puerto.PrtTomcat ;
                //    listView1.Items[5].SubItems[3].Text = "Parado";
                //}
            }
            */
        }

        private void FmrHox_Load_1(object sender, EventArgs e){
            InfoProgramas Progrmas = new InfoProgramas();
            Progrmas.Escribir();  
        }
		void HttpwwwworlcomcomToolStripMenuItemClick(object sender, EventArgs e)
		{
	
		}

        
            
            }
        }
    

