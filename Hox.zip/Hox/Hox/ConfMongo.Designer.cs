﻿namespace Hox
{
    partial class ConfMongo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        	this.tabControl1 = new System.Windows.Forms.TabControl();
        	this.tabPage2 = new System.Windows.Forms.TabPage();
        	this.BtnMongo = new System.Windows.Forms.Button();
        	this.TextMongo = new System.Windows.Forms.TextBox();
        	this.label2 = new System.Windows.Forms.Label();
        	this.BtnGuardar = new System.Windows.Forms.Button();
        	this.tabControl1.SuspendLayout();
        	this.tabPage2.SuspendLayout();
        	this.SuspendLayout();
        	// 
        	// tabControl1
        	// 
        	this.tabControl1.Controls.Add(this.tabPage2);
        	this.tabControl1.Location = new System.Drawing.Point(14, 11);
        	this.tabControl1.Name = "tabControl1";
        	this.tabControl1.SelectedIndex = 0;
        	this.tabControl1.Size = new System.Drawing.Size(571, 200);
        	this.tabControl1.TabIndex = 0;
        	// 
        	// tabPage2
        	// 
        	this.tabPage2.Controls.Add(this.BtnMongo);
        	this.tabPage2.Controls.Add(this.TextMongo);
        	this.tabPage2.Controls.Add(this.label2);
        	this.tabPage2.Location = new System.Drawing.Point(4, 22);
        	this.tabPage2.Name = "tabPage2";
        	this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
        	this.tabPage2.Size = new System.Drawing.Size(563, 174);
        	this.tabPage2.TabIndex = 1;
        	this.tabPage2.Text = "MongoDB";
        	this.tabPage2.UseVisualStyleBackColor = true;
        	// 
        	// BtnMongo
        	// 
        	this.BtnMongo.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.BtnMongo.Location = new System.Drawing.Point(393, 57);
        	this.BtnMongo.Name = "BtnMongo";
        	this.BtnMongo.Size = new System.Drawing.Size(75, 26);
        	this.BtnMongo.TabIndex = 4;
        	this.BtnMongo.Text = "::";
        	this.BtnMongo.UseVisualStyleBackColor = true;
        	// 
        	// TextMongo
        	// 
        	this.TextMongo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.TextMongo.Location = new System.Drawing.Point(133, 59);
        	this.TextMongo.Name = "TextMongo";
        	this.TextMongo.Size = new System.Drawing.Size(254, 24);
        	this.TextMongo.TabIndex = 3;
        	// 
        	// label2
        	// 
        	this.label2.AutoSize = true;
        	this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label2.Location = new System.Drawing.Point(82, 62);
        	this.label2.Name = "label2";
        	this.label2.Size = new System.Drawing.Size(44, 18);
        	this.label2.TabIndex = 1;
        	this.label2.Text = "Ruta:";
        	// 
        	// BtnGuardar
        	// 
        	this.BtnGuardar.Location = new System.Drawing.Point(504, 214);
        	this.BtnGuardar.Name = "BtnGuardar";
        	this.BtnGuardar.Size = new System.Drawing.Size(79, 30);
        	this.BtnGuardar.TabIndex = 1;
        	this.BtnGuardar.Text = "Guardar";
        	this.BtnGuardar.UseVisualStyleBackColor = true;
        	// 
        	// ConfMongo
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.ClientSize = new System.Drawing.Size(595, 249);
        	this.Controls.Add(this.BtnGuardar);
        	this.Controls.Add(this.tabControl1);
        	this.MaximizeBox = false;
        	this.MinimizeBox = false;
        	this.Name = "ConfMongo";
        	this.ShowIcon = false;
        	this.ShowInTaskbar = false;
        	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        	this.Text = "Ruta Mongo";
        	this.tabControl1.ResumeLayout(false);
        	this.tabPage2.ResumeLayout(false);
        	this.tabPage2.PerformLayout();
        	this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button BtnMongo;
        private System.Windows.Forms.TextBox TextMongo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BtnGuardar;
    }
}