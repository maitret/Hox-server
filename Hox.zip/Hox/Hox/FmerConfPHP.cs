﻿//Entorno de desarrollo para aplicaciones web Alternativa a Xampp, Wamp Appserv y demás, 
// Copyright (C ) Rodrigo Chambi Q, Email infohoxserver@asqki.com http://www.hoxserver.asqki.com
//
// Este programa es software libre; usted puede redistribuirlo y / o
// Modificarlo bajo los términos de la Licencia Pública General de GNU
// Publicada por la Free Software Foundation; ya sea la versión 2
// De la Licencia, o (a su elección) cualquier versión posterior .
//
// Este programa se distribuye con la esperanza de que sea útil,
// Pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de
// COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. ver el

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO; 
using System.Text.RegularExpressions;  
namespace Hox
{
    public partial class FmerConfPHP : Form
    {
        public FmerConfPHP()
        {
            InitializeComponent();
            
            BtbnGuardar.Click += BtbnGuardar_Click;
            CheckAviso.CheckedChanged += CheckAviso_CheckedChanged;
            CheckEstric.CheckedChanged += CheckAviso_CheckedChanged;
            ChekAdver.CheckedChanged += CheckAviso_CheckedChanged;
           
            this.Load += new EventHandler(FmerConfPHP_Load);
        }

        private string ArPHPini=string.Empty;
        void FmerConfPHP_Load(object sender, EventArgs e){
        	ArPHPini=ChangePHP.PHPRuta;
            ListExtension.ItemChecked += ListExtension_ItemCheck;
            LeerPHPfileINI(ArPHPini+@"\php.ini");
            OpHabilit(ArPHPini+@"\php.ini");
        }

        private string LineasModif = string.Empty; 
        String[] Valor;
        private void OpHabilit(string phat) {
            try{
                
                StreamReader LeerArch = new StreamReader(phat);
                String LineasModif = "";
                Regex Busqueda = new Regex(@"^error_reporting");
                while ((LineasModif = LeerArch.ReadLine()) != null){
                    if (Busqueda.IsMatch(LineasModif)){
                        String[] Quitar = LineasModif.Split('=');
                        Valor = Quitar[1].ToString().Replace(" ","").Split('&');
                    }
                   
                }
               foreach (string lista in Valor) {
                	//MessageBox.Show (lista );
                	if(lista == "E_ALL"){
                		CheckAviso.Checked=true ;
                	}
                	if(lista == "~E_CORE_WARNING"){
                		ChekAdver.Checked=true;
                	}
                	
                	if(lista == "~E_STRICT"){
                		CheckEstric.Checked=true;
                	}

                            
                        }
             }
            catch (Exception e) {
        		MessageBox.Show(e.Message);
            }
        }


        /// <summary>
        /// Con esta funcion se extrea la lista de extenciones habilitados y no habilitados
        /// </summary>
        private void LeerPHPfileINI(String Phat){
            try{
                ListExtension.Items.Clear();
                string rutaExtension = ArPHPini+ @"\ext\"; 
                StreamReader LeerArch = new StreamReader(Phat ); 
                String Lineas="";
                Regex Busqueda = new Regex(@"^\S+\.dll""?$");
                while ((Lineas = LeerArch.ReadLine()) != null)
                {

                    if (Busqueda.IsMatch(Lineas))
                    {
                        ListViewItem Intem = new ListViewItem();
                        Regex SegundaBus = new Regex(@"^;\S+\.dll""?$");

                        if (SegundaBus.IsMatch(Lineas)) //si que se inclui extension Zend
                        {
                            String[] Valor1=Lineas.Split('=');
                            Intem.Checked = false;
                            Intem.Text = Valor1[1];
                           // MessageBox.Show(rutaExtension + Valor1[1]);
                            if (File.Exists(rutaExtension + Valor1[1])){
                                Intem.SubItems.Add(rutaExtension + Valor1[1]);
                                Intem.SubItems.Add("Disponible");
                            }
                            else {
                                Intem.ForeColor = Color.Red;   
                                Intem.SubItems.Add(rutaExtension+"?");
                                Intem.SubItems.Add("No disponible");
                            }
                            ListExtension.Items.Add(Intem);
                            //ListExtension.Items.Add(Valor1[1],false );    
                        }
                        else { 
                            String[] Valor2 = Lineas.Split('=');
                            Intem.Checked = true;
                            Intem.Text = Valor2[1];
                            if(File.Exists (rutaExtension+Valor2[1])){
                                Intem.SubItems.Add(rutaExtension + Valor2[1]);
                                Intem.SubItems.Add("Disponible");
                                ListExtension.Items.Add(Intem);
                            }
                           // ListExtension.Items.Add(Valor2[1],true );
                        }
                    }
                }
                LeerArch.Close ();
            }
            catch (Exception ss) { 
            
            }
        
        }

        private string HabilitDeubg = "";
       /// <summary>
       /// No permite la deshabilitacion del Aviso
       /// para mostrar errores flagrandes
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
        private void CheckAviso_CheckedChanged(object sender, EventArgs e){
            CheckBox hab = (CheckBox)sender;
            if (hab.Text == "Aviso")
            {
                hab.Checked = true;
            }
 
        }

        private string RescateExtension = "";
       private cIniArray mINI = new cIniArray();
        /// <summary>
        /// Guarda el archivo de configuracion 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void BtbnGuardar_Click(object sender, EventArgs e){
            if (tabControl1.SelectedIndex == 0){
                

            }
            else {
                 Listado();//recupera la opcion de fonfiguracion
                 mINI.IniWrite(ArPHPini, "PHP", "error_reporting", HabilitDeubg); 
                
            }
           
        }
        private void Listado() {
            HabilitDeubg = "";

            foreach (object obej in groupBox1.Controls) {
                CheckBox item = (CheckBox)obej;
                if (item.Text == "Aviso")
                {
                    if (item.Checked == true)
                    {
                        HabilitDeubg += " E_ALL";

                    }
                }
                if (item.Text == "Estàndares estrictos")
                {
                    if (item.Checked == true)
                    {
                        HabilitDeubg += " & ~E_STRICT";

                    }

                }
                if (item.Text == "Advertencia")
                {
                    if (item.Checked == true)
                    {
                        HabilitDeubg += " & ~E_CORE_WARNING";
                    }
                }
            }
                
               
           
        }

        private void ListExtension_ItemCheck(object sender, ItemCheckedEventArgs e)
        {
           // MessageBox.Show(e.Item.Text );  
        }
    }
}
