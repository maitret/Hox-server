﻿//Entorno de desarrollo para aplicaciones web Alternativa a Xampp, Wamp Appserv y demás, 
// Copyright (C ) Rodrigo Chambi Q, Email infohoxserver@asqki.com http://www.hoxserver.asqki.com
//
// Este programa es software libre; usted puede redistribuirlo y / o
// Modificarlo bajo los términos de la Licencia Pública General de GNU
// Publicada por la Free Software Foundation; ya sea la versión 2
// De la Licencia, o (a su elección) cualquier versión posterior .
//
// Este programa se distribuye con la esperanza de que sea útil,
// Pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de
// COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. ver el

using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32; 
using System.Xml ;
using System.Text.RegularExpressions;  
internal interface ILerPuerto
{
    void LeerConfigApache();//Metodo para leer archvi de configuracion Apache
    void LeerIniMysql();//Metodo para leer archivo de configuracion MySQL
    void LeerFilezilla();//Metodo para leer archvi de configuracion FiliZilla
    void LeerMercury();//Metodo para leer archivo de configuracion Mercury
    void LeerTomcat();//Metodo para leer archivo de configuracion Tomcat
    void LeerArgosoft();//Metodo para leer archivo de configuracion  Argosoft
}

public  class LeerPuerto:ILerPuerto
{
    public LeerPuerto()
    {
        
    }

  

 
    //Atributos
    private String Puerto_Apache_;
    private String Puerto_Mysql_;
    private String Puerto_FiliZilla_;
    private String Puerto_Mercury_;
    private String Puerto_Tomcact_;
    private String Puerto_Argosoft_;
    private string Puerto_PostgreSQL_;
    private String[] Puertos = new String[] {"","","","","","",""}; 
    /// <summary>
    /// Lee la configruacion del apache
    /// </summary>
   public  void LeerConfigApache()
    {
        String Arcchivo = Application.StartupPath + @"\Programas\apache\conf\httpd.conf";
        if (File.Exists(Arcchivo)){
            StreamReader LeerArch = new StreamReader(Arcchivo);
            String Lineas = "";
            while ((Lineas = LeerArch.ReadLine()) != null)//implementar expresiones regulares para capturar los datos
            {
                String[] Valor = Lineas.Split(' ');
                if (Valor[0] == "Listen")
                {
                    Puerto_Apache_ = Valor[1].ToString();//rescantado  el host del apache
                    Puertos[0] = Valor[1].ToString(); 
                }
            }
            LeerArch.Close();  

        }
        else { 
        
        }
    }
    /// <summary>
    /// Lee la configuracion  de MySQL
    /// </summary>
    public  void LeerIniMysql()
    {
        String Arcchivo = Application.StartupPath + @"\Programas\mysql\bin\my.ini";
        if (File.Exists(Arcchivo))
        {
            try {
                StreamReader LeerArch = new StreamReader(Arcchivo);
                String Lineas = "";
                while ((Lineas = LeerArch.ReadLine()) != null)//implementar lectura de archivo INI
                {
                    String[] Valor = Lineas.Split('=');
                    if (Valor[0] == "port            ")
                    {
                        Puerto_Mysql_ = Valor[1].ToString();//rescantado  el puerto de MySQL  
                        Puertos[1] = Valor[1].ToString();

                    }
                }
                LeerArch.Close(); 
            }
            catch (Exception ss) { }

        }
        else
        {
            try {
                StreamReader LeerArch = new StreamReader(@"Programas\mysql\my-large.ini");
                String Lineas = "";
                while ((Lineas = LeerArch.ReadLine()) != null)//implementar lectura de archivo INI
                {
                    String[] Valor = Lineas.Split('=');
                    if (Valor[0] == "port		")
                    {
                        Puerto_Mysql_ = Valor[1].ToString();//rescantado  el puerto de MySQL  
                        Puertos[1] = Valor[1].ToString();

                    }
                }
                LeerArch.Close();
            
            }
            catch (Exception ss) { }
            
        }
    }
    /// <summary>
    /// Lee la configuracion del FileZilla
    /// </summary>
    public  void LeerFilezilla() {

        String Arcchivo = Application.StartupPath + @"\Programas\FileZillaFTP\FileZilla Server.xml";
        if (File.Exists(Arcchivo))
        {
            LeerArchivoFiliZi(Arcchivo);
        }
        
    }
    private void LeerArchivoFiliZi( string Phat)
    {
        bool Encontrado = false;
        //Serverport

        XmlTextReader LerXml = new XmlTextReader(Phat);
        LerXml.MoveToContent();
        bool ItemNext = true;
        while (LerXml.Read())
        {
            if (ItemNext)
            { ItemNext = false; }



            switch (LerXml.NodeType)
            {
                case XmlNodeType.Element:

                    while (LerXml.MoveToNextAttribute())


                        if (LerXml.Value == "Serverport")
                        {
                            Encontrado = true;
                        }

                    break;
                case XmlNodeType.Text:
                    if (Encontrado == true)
                    {
                        Puerto_FiliZilla_ = LerXml.Value;//recuperando el puerto 
                        Puertos[2] = LerXml.Value.ToString()  ;
                        Encontrado = false;
                    }

                    break;
            }
        }
        LerXml.Close();

    }


    /// <summary>
    /// Lee la configuracion de Mercury
    /// </summary>
    public void LeerMercury()
    {
        String Arcchivo = Application.StartupPath + @"\Programas\MercuryMail\mercury.ini";
        string Valors = "";
        int Contado = 0;
        if (File.Exists(Arcchivo))
        {
            StreamReader LeerArch = new StreamReader(Arcchivo);
            String Lineas = "";
            while ((Lineas = LeerArch.ReadLine()) != null)//implementar lectura de archivo INI
            {
                String[] Valor = Lineas.Split(':');
                if (Valor[0] == "Server_Port ")
                {
                    Contado++;
                    switch (Contado)
                    {
                        case 1:
                            Valors += Valor[1].ToString();
                            break;
                        case 2:
                            Valors += "," + Valor[1].ToString();
                            break;
                    }

                }

            }
            LeerArch.Close();  

            Puerto_Mercury_ = Valors;//recuperando el puerto de Mercury
            Puertos[3] = Valors.ToString(); 
        }
        else
        {

        }
    }
    public void LeerTomcat()
    {
        String Arcchivo = Application.StartupPath + @"\Programas\tomcat\conf\server.xml";
        if (File.Exists(Arcchivo))
        {
            LeerTomcat(Arcchivo);
            Puertos[4] = Puerto_Tomcact_;
        }
    }

    private void LeerTomcat(string Phat)
    {

        //Serverport
        String Puertos = "";
        int Contador = 0;
        XmlTextReader LerXml = new XmlTextReader(Phat);
        LerXml.MoveToContent();
        bool ItemNext = true;
        while (LerXml.Read())
        {
            if (ItemNext)
            { ItemNext = false; }



            switch (LerXml.NodeType)
            {
                case XmlNodeType.Element:
                    while (LerXml.MoveToNextAttribute())
                        if (LerXml.Name == "port")
                        {

                            Contador++;
                            if (Contador == 1)
                            {
                                Puertos += LerXml.Value;
                            }
                            if (Contador == 2)
                            {

                                Puertos += "," + LerXml.Value;
                            }
                        }


                    break;

            }

        }
        Puerto_Tomcact_ = Puertos;
        
        LerXml.Close();

    }


    /// <summary>
    /// Lee la configuracion de ArgosoftMail
    /// </summary>
    public void LeerArgosoft()
    {
        try
        {

            RegistryKey Valor = Registry.CurrentUser.OpenSubKey(@"Software\ArGoSoft\Mail Server\Setup");
            String str = Valor.GetValue("SMTP Port").ToString() + "," + Valor.GetValue("Web Port").ToString();
            Puerto_Argosoft_ = str;//retorna el puerto  de argosoft
            Puertos[5] = Puerto_Argosoft_.ToString();
        }
        catch (Exception ss) { }

    }


    public void LeerPostgreSQL()
    {
        string Valors = "";

        try
        {
            String Arcchivo = Application.StartupPath + @"\Programas\PostGreSQL\data\postgresql.conf";

            if (File.Exists(Arcchivo))
            {
                StreamReader LeerArch = new StreamReader(Arcchivo);
                String Lineas = "";
                while ((Lineas = LeerArch.ReadLine()) != null)//implementar lectura de archivo config
                {
                    Regex Buscar = new Regex(@"port");
                    if (Buscar.IsMatch(Lineas))
                    {
                     
                        String[] Valor = Lineas.Split('=');

                            Valors = Valor[1].Substring(0, (Valor[1].Length - (Valor[1].Length - 6))); 
                    }
                    else
                    {

                    }
                   
                }
                LeerArch.Close();  

            }

        }
        catch (Exception   es) { 
        
        }
        Puerto_PostgreSQL_ = Valors;//recuperando el puerto de Postgre 
    }

    /// <summary>
    /// Devuelve puerto de Apache
    /// </summary>
    public  string PrtApache {
        get { return Puerto_Apache_; }
        set { Puerto_Apache_ = value; 
       //Establece el puerto para apache
        } 
    }
    /// <summary>
    /// Devuelve puert de MySQL
    /// </summary>
    public string PrtMySQL {
        get { return Puerto_Mysql_; }
        set { Puerto_Mysql_ = value;
        //establecer Puerto para Mysql
        }

      
    }

    /// <summary>
    /// Devuelve puerto de FileZilla
    /// </summary>
    public string PrtFiliZilla {
        get { return Puerto_FiliZilla_; }
        set { Puerto_FiliZilla_ = value; } 
    }
    /// <summary>
    /// Devuelve puerto de Mercury
    /// </summary>
    public string PrtMercury {
        get { return Puerto_Mercury_; }
        set { Puerto_Mercury_ = value; }
    }
    /// <summary>
    /// Devuelve puerto de tomcat
    /// </summary>
    public String PrtTomcat {
        get { return Puerto_Tomcact_; }
        set { Puerto_Tomcact_ = value; } 
    }
    /// <summary>
    /// Devuelve puerto  argosoft
    /// </summary>
    public string PrtArgosoft {
        get { return Puerto_Argosoft_; }
        set { Puerto_Argosoft_ = value; }
    }
    /// <summary>
    /// Devuelve el puerto de postegreSQL
    /// </summary>
    public String PrtPostgreSQL {
        get { return Puerto_PostgreSQL_; }
        set { Puerto_PostgreSQL_ = value; }
    }
    /// <summary>
    /// Obtiene el puerto de MongoDB
    /// </summary>
    public String PrtMongoDB {
        get { return "27017"; }
    }

    public String[] ListaPuertos {
        get { return Puertos; }
    } 
}


public class InfoProgramas
{
    public InfoProgramas()
    {
         
    }

    public void Escribir()
    {
        String[] Nombres = new String[] {"Apache","MySQL","FileZilla","Mercury","Tomcat","ArgoSoftMail","PostgreSQL" }; 
        LeerPuerto Puertos = new LeerPuerto();
        Puertos.LeerConfigApache();
        Puertos.LeerIniMysql() ;
        Puertos.LeerFilezilla() ;
        Puertos.LeerMercury() ;
        Puertos.LeerTomcat() ;
        Puertos.LeerArgosoft() ;
        Puertos.LeerPostgreSQL();

        try
        {
            XmlTextWriter Escribir = new XmlTextWriter(Application.StartupPath + "\\Puertos.xml", Encoding.UTF8);
            Escribir.Formatting = Formatting.Indented;
            Escribir.WriteStartDocument();
            Escribir.WriteStartElement("Puertos");
            for (int i = 0; i <= Puertos.ListaPuertos.Length-1; i++)
            {
                
                Escribir.WriteElementString(Nombres[i].ToString(), Puertos.ListaPuertos[i].ToString());
            }
            Escribir.WriteEndElement();
            Escribir.WriteEndDocument();
            Escribir.Flush();
            Escribir.Close();
        }
        catch (Exception vista)
        {
            //MessageBox.Show(vista.Message);   
        } 
  

        //EscriXML(); 
    }
  
       



}


public class RutaDBMongo {

    public RutaDBMongo(OpcionRuta opcion)
    {
        if (opcion == OpcionRuta.Leer) {
            LeerRuta();
        }

    }
        /// </summary>
        /// Constructor Asignar en su parametro
        /// Ruta de archivo Xml
        /// </summary>
        /// <param name="phat">Ruta del Archivo XML</param>
        /// <param name="opcion">Opcion de lectura y escritura</param>
    public RutaDBMongo(string phat, OpcionRuta opcion)
    {
            RutXml = phat;
            if (opcion == OpcionRuta.Escribir) {
                EscribirRuta(phat);
               
            }
        
        }
        //Opcion de abrir y escribir archivo
        //ruta de xml
        public enum OpcionRuta {
            Leer,
            Escribir
        }
        private String RutXml;
        /// <summary>
        /// Obtiene la ruta de base de datos
        /// de mogo DB
        /// </summary>
        public String RutaDB {
            get { return RutXml; }
        }
        private void LeerRuta() {
            //Serverport
            String Ruta = "";
            //int Contador = 0;
            XmlTextReader LerXml = new XmlTextReader(Application.StartupPath + @"\RutaDB.xml");
            LerXml.MoveToContent();
            while (LerXml.Read()){
                 if (LerXml.NodeType == XmlNodeType.Text) {
                   Ruta=LerXml.Value; 
                }
            }
            RutXml = Ruta;

            LerXml.Close();
        }
        /// <summary>
        /// Escribe la ruta de base de datos
        /// del MongoDB
        /// </summary>
        /// <param name="path"></param>
        private void EscribirRuta(string path) { 
        try{
            XmlTextWriter Escribir = new XmlTextWriter(Application.StartupPath + @"\RutaDB.xml", Encoding.UTF8);
            Escribir.Formatting = Formatting.Indented;
            Escribir.WriteStartDocument();
            Escribir.WriteStartElement("RutaDB");
            Escribir.WriteElementString("MongDB", path);
            Escribir.WriteEndElement();
            Escribir.WriteEndDocument();
            Escribir.Flush();
            Escribir.Close();
        }
        catch (Exception vista){
            //MessageBox.Show(vista.Message);   
        } 
        }


}