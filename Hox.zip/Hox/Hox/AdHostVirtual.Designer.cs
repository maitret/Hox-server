﻿namespace Hox
{
    partial class AdHostVirtual
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        	this.groupBox2 = new System.Windows.Forms.GroupBox();
        	this.label6 = new System.Windows.Forms.Label();
        	this.label5 = new System.Windows.Forms.Label();
        	this.BtnDom = new System.Windows.Forms.Button();
        	this.label3 = new System.Windows.Forms.Label();
        	this.comboBox2 = new System.Windows.Forms.ComboBox();
        	this.label4 = new System.Windows.Forms.Label();
        	this.textBox2 = new System.Windows.Forms.TextBox();
        	this.groupBox1 = new System.Windows.Forms.GroupBox();
        	this.label8 = new System.Windows.Forms.Label();
        	this.label7 = new System.Windows.Forms.Label();
        	this.btnSubDom = new System.Windows.Forms.Button();
        	this.label2 = new System.Windows.Forms.Label();
        	this.comboBox1 = new System.Windows.Forms.ComboBox();
        	this.label1 = new System.Windows.Forms.Label();
        	this.textBox1 = new System.Windows.Forms.TextBox();
        	this.BtnAceptar = new System.Windows.Forms.Button();
        	this.BtnCancel = new System.Windows.Forms.Button();
        	this.groupBox2.SuspendLayout();
        	this.groupBox1.SuspendLayout();
        	this.SuspendLayout();
        	// 
        	// groupBox2
        	// 
        	this.groupBox2.Controls.Add(this.label6);
        	this.groupBox2.Controls.Add(this.label5);
        	this.groupBox2.Controls.Add(this.BtnDom);
        	this.groupBox2.Controls.Add(this.label3);
        	this.groupBox2.Controls.Add(this.comboBox2);
        	this.groupBox2.Controls.Add(this.label4);
        	this.groupBox2.Controls.Add(this.textBox2);
        	this.groupBox2.Location = new System.Drawing.Point(3, 6);
        	this.groupBox2.Name = "groupBox2";
        	this.groupBox2.Size = new System.Drawing.Size(463, 150);
        	this.groupBox2.TabIndex = 9;
        	this.groupBox2.TabStop = false;
        	this.groupBox2.Text = "Dominio";
        	this.groupBox2.Enter += new System.EventHandler(this.GroupBox2Enter);
        	// 
        	// label6
        	// 
        	this.label6.AutoSize = true;
        	this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
        	this.label6.Location = new System.Drawing.Point(180, 84);
        	this.label6.Name = "label6";
        	this.label6.Size = new System.Drawing.Size(136, 13);
        	this.label6.TabIndex = 12;
        	this.label6.Text = "D:\\public_html o D:\\htdocs";
        	// 
        	// label5
        	// 
        	this.label5.AutoSize = true;
        	this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
        	this.label5.Location = new System.Drawing.Point(199, 31);
        	this.label5.Name = "label5";
        	this.label5.Size = new System.Drawing.Size(86, 13);
        	this.label5.TabIndex = 11;
        	this.label5.Text = "www.server.com";
        	// 
        	// BtnDom
        	// 
        	this.BtnDom.Location = new System.Drawing.Point(381, 96);
        	this.BtnDom.Name = "BtnDom";
        	this.BtnDom.Size = new System.Drawing.Size(57, 31);
        	this.BtnDom.TabIndex = 6;
        	this.BtnDom.Text = "::";
        	this.BtnDom.UseVisualStyleBackColor = true;
        	// 
        	// label3
        	// 
        	this.label3.AutoSize = true;
        	this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label3.Location = new System.Drawing.Point(11, 109);
        	this.label3.Name = "label3";
        	this.label3.Size = new System.Drawing.Size(40, 18);
        	this.label3.TabIndex = 10;
        	this.label3.Text = "Ruta";
        	// 
        	// comboBox2
        	// 
        	this.comboBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.comboBox2.FormattingEnabled = true;
        	this.comboBox2.Location = new System.Drawing.Point(137, 100);
        	this.comboBox2.Name = "comboBox2";
        	this.comboBox2.Size = new System.Drawing.Size(236, 26);
        	this.comboBox2.TabIndex = 7;
        	// 
        	// label4
        	// 
        	this.label4.AutoSize = true;
        	this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label4.Location = new System.Drawing.Point(11, 47);
        	this.label4.Name = "label4";
        	this.label4.Size = new System.Drawing.Size(118, 18);
        	this.label4.TabIndex = 9;
        	this.label4.Text = "Nombre Server:";
        	// 
        	// textBox2
        	// 
        	this.textBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.textBox2.Location = new System.Drawing.Point(137, 47);
        	this.textBox2.Name = "textBox2";
        	this.textBox2.Size = new System.Drawing.Size(236, 26);
        	this.textBox2.TabIndex = 8;
        	// 
        	// groupBox1
        	// 
        	this.groupBox1.Controls.Add(this.label8);
        	this.groupBox1.Controls.Add(this.label7);
        	this.groupBox1.Controls.Add(this.btnSubDom);
        	this.groupBox1.Controls.Add(this.label2);
        	this.groupBox1.Controls.Add(this.comboBox1);
        	this.groupBox1.Controls.Add(this.label1);
        	this.groupBox1.Controls.Add(this.textBox1);
        	this.groupBox1.Location = new System.Drawing.Point(3, 162);
        	this.groupBox1.Name = "groupBox1";
        	this.groupBox1.Size = new System.Drawing.Size(464, 106);
        	this.groupBox1.TabIndex = 8;
        	this.groupBox1.TabStop = false;
        	this.groupBox1.Text = "Sub dominio";
        	// 
        	// label8
        	// 
        	this.label8.AutoSize = true;
        	this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label8.ForeColor = System.Drawing.SystemColors.HotTrack;
        	this.label8.Location = new System.Drawing.Point(199, 55);
        	this.label8.Name = "label8";
        	this.label8.Size = new System.Drawing.Size(104, 13);
        	this.label8.TabIndex = 13;
        	this.label8.Text = "D:\\public_html\\docs";
        	// 
        	// label7
        	// 
        	this.label7.AutoSize = true;
        	this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label7.ForeColor = System.Drawing.SystemColors.HotTrack;
        	this.label7.Location = new System.Drawing.Point(213, 10);
        	this.label7.Name = "label7";
        	this.label7.Size = new System.Drawing.Size(63, 13);
        	this.label7.TabIndex = 12;
        	this.label7.Text = "sub dominio";
        	// 
        	// btnSubDom
        	// 
        	this.btnSubDom.Location = new System.Drawing.Point(382, 68);
        	this.btnSubDom.Name = "btnSubDom";
        	this.btnSubDom.Size = new System.Drawing.Size(57, 31);
        	this.btnSubDom.TabIndex = 0;
        	this.btnSubDom.Text = "::";
        	this.btnSubDom.UseVisualStyleBackColor = true;
        	// 
        	// label2
        	// 
        	this.label2.AutoSize = true;
        	this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label2.Location = new System.Drawing.Point(7, 78);
        	this.label2.Name = "label2";
        	this.label2.Size = new System.Drawing.Size(40, 18);
        	this.label2.TabIndex = 5;
        	this.label2.Text = "Ruta";
        	// 
        	// comboBox1
        	// 
        	this.comboBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.comboBox1.FormattingEnabled = true;
        	this.comboBox1.Location = new System.Drawing.Point(133, 70);
        	this.comboBox1.Name = "comboBox1";
        	this.comboBox1.Size = new System.Drawing.Size(236, 26);
        	this.comboBox1.TabIndex = 1;
        	// 
        	// label1
        	// 
        	this.label1.AutoSize = true;
        	this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.label1.Location = new System.Drawing.Point(7, 26);
        	this.label1.Name = "label1";
        	this.label1.Size = new System.Drawing.Size(43, 18);
        	this.label1.TabIndex = 4;
        	this.label1.Text = "Alias";
        	// 
        	// textBox1
        	// 
        	this.textBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.textBox1.Location = new System.Drawing.Point(133, 26);
        	this.textBox1.Name = "textBox1";
        	this.textBox1.Size = new System.Drawing.Size(236, 26);
        	this.textBox1.TabIndex = 3;
        	// 
        	// BtnAceptar
        	// 
        	this.BtnAceptar.Location = new System.Drawing.Point(392, 274);
        	this.BtnAceptar.Name = "BtnAceptar";
        	this.BtnAceptar.Size = new System.Drawing.Size(75, 23);
        	this.BtnAceptar.TabIndex = 10;
        	this.BtnAceptar.Text = "Aceptar";
        	this.BtnAceptar.UseVisualStyleBackColor = true;
        	// 
        	// BtnCancel
        	// 
        	this.BtnCancel.Location = new System.Drawing.Point(311, 274);
        	this.BtnCancel.Name = "BtnCancel";
        	this.BtnCancel.Size = new System.Drawing.Size(75, 23);
        	this.BtnCancel.TabIndex = 11;
        	this.BtnCancel.Text = "Cancelar";
        	this.BtnCancel.UseVisualStyleBackColor = true;
        	// 
        	// AdHostVirtual
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.ClientSize = new System.Drawing.Size(472, 303);
        	this.Controls.Add(this.BtnCancel);
        	this.Controls.Add(this.BtnAceptar);
        	this.Controls.Add(this.groupBox2);
        	this.Controls.Add(this.groupBox1);
        	this.MaximizeBox = false;
        	this.MinimizeBox = false;
        	this.Name = "AdHostVirtual";
        	this.ShowIcon = false;
        	this.ShowInTaskbar = false;
        	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        	this.Text = "Agegar dominios locales";
        	this.Load += new System.EventHandler(this.AdHostVirtualLoad);
        	this.groupBox2.ResumeLayout(false);
        	this.groupBox2.PerformLayout();
        	this.groupBox1.ResumeLayout(false);
        	this.groupBox1.PerformLayout();
        	this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BtnDom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSubDom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BtnAceptar;
        private System.Windows.Forms.Button BtnCancel;
    }
}