﻿//Entorno de desarrollo para aplicaciones web Alternativa a Xampp, Wamp Appserv y demás, 
// Copyright (C ) Rodrigo Chambi Q, Email infohoxserver@asqki.com http://www.hoxserver.asqki.com
//
// Este programa es software libre; usted puede redistribuirlo y / o
// Modificarlo bajo los términos de la Licencia Pública General de GNU
// Publicada por la Free Software Foundation; ya sea la versión 2
// De la Licencia, o (a su elección) cualquier versión posterior .
//
// Este programa se distribuye con la esperanza de que sea útil,
// Pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de
// COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. ver el


using System;
using System.IO;
using System.Diagnostics;
using System.Threading;   
using System.Collections;
using System.Windows.Forms;
using System.Linq;
 namespace SatartStop{
     //Declaracion del los eventos al monento de iniciar y parado
     public delegate void AplicacionIniciado(object objeto, String[] Nombre);
     public delegate void AplicaionParado(object obejto,String[] Nombre );
     /// <summary>
         /// Opciones cierre de aplicacion
         /// </summary>
        public enum close { 
        window,
        noting
        }
     /// <summary>
     /// Interfaz declarado
     /// </summary>
     interface IEjectarAplicacion{
          void  Iniciar(String Phat);
          void Parar(String Nombre, close tipo );
          ArrayList ProgEjecut
          {
              get;
          }
         event AplicacionIniciado  Iniciado;
         event AplicaionParado Parado;
         }

     public class EjecutarAplicaiones:IEjectarAplicacion{
         /// <summary>
         /// Constructor por defecto
         /// </summary>
         public EjecutarAplicaiones()
         { 
         }
         //Sector de los eventos
        public  event AplicacionIniciado  Iniciado;
        public  event AplicaionParado Parado;

         //Atributos de almacenacion 
         private String Nombre_ = String.Empty;//Alamcena el nombre de la Aplicacion
         private String PID_ = String.Empty;//Almacena el PID(s) de la aplicacion
         private String Puerto_ = String.Empty;//Almacena El PORT(s) de la aplicacion
         private String Proceso_ = String.Empty;//Almacena el estado actual de la aplicacion 
         private ArrayList Aplicaciones_ = new ArrayList();//Almacena nombres de aplicaciones en ejecucion
         private String[] Nombres_Apli = new String[] { "httpd", "mysqld", "FileZillaServer", "mercury", "catalina_start", "mailserver","mongod" };//nombre de los archivos ejecutables  
         private Process MiProceso = new Process();//Instancia de la clase Process que nos provee de jecutar aplicaciones y cerrar
         ProcessStartInfo Procesar = new ProcessStartInfo();//Proceso de informacion del archivo ejecutable
         private string[] Lista_Iniciado=new string[]{"","","","","",""} ;
         private bool Valor_Iniciado = false;//Alamcena el valor iniciado pro defecto false valor no iniciado
         private LeerPuerto LecturaPuerto = new LeerPuerto();
         private String Mostrar_Tipos = String.Empty;// 
         /// <summary>
         /// Comprueba una aplicacion  si es que se esta ejecutando
         /// en el Proceso
         /// </summary>
         /// <param name="NameAplication">Nombre de la aplicacion</param>
         /// <returns> false o true</returns>
         public bool ComprobarApli( string NameAplication)
         {
         	bool exist =false;
             Process[] numbers = Process.GetProcesses();
            var ListProces =
                from n in numbers
                where n.ProcessName == NameAplication
                select n;
            exist= ListProces.Any();
             /*Cambiado por el bug
              * foreach (Process list in Process.GetProcesses())
             {
                 if (list.ProcessName != NameAplication)
                     continue;
                 retornar = true;
             }*/
             return exist;
         }
         /// <summary>
         /// Metodo Para Iniciar La aplicacion
         /// </summary>
         /// <param name="Phat"></param>
        public  void  Iniciar(string Phat){
           
            //obeteniendo  el Nombre de la Aplicacion
            if (File.Exists(Phat) ){
                string Nombre_Recuperado = "";
                FileInfo InformacionArc = new FileInfo(Phat);
                Nombre_Recuperado = InformacionArc.Name.Substring(0, (InformacionArc.Name.Length - 4));//se obtiene el nombre del ejecutable
              
                switch (Nombre_Recuperado)
                {
                    case "httpd":
                        #region "Apache"
                        //aplicacion Apache
                        Procesar.FileName = InformacionArc.FullName;
                        Procesar.WindowStyle = ProcessWindowStyle.Hidden;
                        //Procesar.CreateNoWindow = true;
                        Procesar.Arguments = "-f " + Application.StartupPath + @"\Programas\apache\conf\httpd.conf";//argumentos para ejecutar la aplicacion
                        MiProceso = Process.Start(Procesar);
                       // Thread.Sleep(2000);
                        //Comprobando el nombre de la aplicacion
                        if (ComprobarApli(Nombre_Recuperado) == true){
                            //Recupera informacion
                            LecturaPuerto.LeerConfigApache();//lee la configuracion Apache  
                            Nombre_ = "Apache";//Nombre de la aplicacion

                            PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                            Puerto_ = LecturaPuerto.PrtApache;//
                            Lista_Iniciado[0] = "Apache";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = MiProceso.Id.ToString();
                            Lista_Iniciado[2] = LecturaPuerto.PrtApache;//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "Iniciado";
                            Lista_Iniciado[4] = Nombres_Apli[0];//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "1";
                            //Lanza el evento
                            AplicacionIniciado Init = Iniciado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                            
                        }else{
                           
                            Lista_Iniciado[0] = "Apache";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = "0";
                            Lista_Iniciado[2] = "0";//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "No iniciado";
                            Lista_Iniciado[4] = Nombres_Apli[0];//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                            AplicaionParado Init = Parado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                        #region "Natiguo algoritmo"
                        //if (Buscar(Nombre_Recuperado) == true)
                        //{

                        //    //si existe la aplicacion Ejecutandose entonces suelta el evento
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    //_____________________________________________________________
                        //}
                        //else
                        //{

                        //    MiProceso = Process.Start(Procesar);
                        //    LecturaPuerto.LeerConfigApache();//lee la configuracion Apache  
                        //    Nombre_ = "Apache";//Nombre de la aplicacion

                        //    PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                        //    Puerto_ = LecturaPuerto.PrtApache;
                        //    Lista_Iniciado[0] = "Apache";
                        //    Lista_Iniciado[1] = MiProceso.Id.ToString();
                        //    Lista_Iniciado[2] = LecturaPuerto.PrtApache;//rescantado la el puerto del apache 
                        //    Lista_Iniciado[3] = "Iniciado";
                        //    Lista_Iniciado[4] = Nombres_Apli[0];//asignamos el nombre del archivo Ejecutable 
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    if (MiProceso.Start())//verificamos si el proceso se ha iniciado
                        //    {
                        //        Proceso_ = "Iniciado";
                        //        Valor_Iniciado = true;
                        //    }
                        //    else
                        //    {
                        //        Proceso_ = "No iniciado";
                        //        Valor_Iniciado = false;
                        //    }
                        //}
                        #endregion 
                        #endregion
                        
                        break;
                    case "mysqld":

                        #region "Mysql"
                        try
                        {
                            Procesar.FileName = InformacionArc.FullName;
                            Procesar.WindowStyle = ProcessWindowStyle.Hidden;
                            Procesar.Arguments = "--defaults-file=" + Application.StartupPath + @"\Programas\mysql\bin\my.ini";
                            Procesar.Arguments = "--standalone";
                            MiProceso = Process.Start(Procesar);
                           // Thread.Sleep(2000);
                            if (ComprobarApli(Nombre_Recuperado) == true) {
                                LecturaPuerto.LeerIniMysql();//lee la configuracion Apache  
                                Nombre_ = "MySQL";//Nombre de la aplicacion

                                PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                                Puerto_ = LecturaPuerto.PrtMySQL;
                                Lista_Iniciado[0] = "MySQL";
                                Lista_Iniciado[1] = MiProceso.Id.ToString();
                                Lista_Iniciado[2] = LecturaPuerto.PrtMySQL;//rescantado la el puerto del apache 
                                Lista_Iniciado[3] = "Iniciado";
                                Lista_Iniciado[4] = "mysqld";//asignamos el nombre del archivo Ejecutable 
                                Lista_Iniciado[5] = "1";
                                //Lanza el evento
                                AplicacionIniciado Init = Iniciado;
                                if (Init != null)
                                {
                                    Init(this, Lista_Iniciado);
                                }
                            }
                            else {
                                
                                Lista_Iniciado[0] = "Apache";//Nombre de la aplicacion 
                                Lista_Iniciado[1] = "0";
                                Lista_Iniciado[2] = "0";//rescantado la el puerto del apache 
                                Lista_Iniciado[3] = "No iniciado";
                                Lista_Iniciado[4] = "mysqld";//asignamos el nombre del archivo Ejecutable 
                                Lista_Iniciado[5] = "0";
                                AplicaionParado Init = Parado;
                                if (Init != null)
                                {
                                    Init(this, Lista_Iniciado);
                                }
                            }
                            //
                            #region "algoritmo antiguro"
                            //if (Buscar(Nombre_Recuperado) == true)
                            //{
                            //    //si existe la aplicacion Ejecutandose entonces suelta el evento
                            //    AplicacionIniciado Init = Iniciado;
                            //    if (Init != null)
                            //    {
                            //        Init(this, Lista_Iniciado);
                            //    }
                            //    //_____________________________________________________________
                            //}
                            //else
                            //{

                            //    MiProceso = Process.Start(Procesar);
                            //    LecturaPuerto.LeerIniMysql();//lee la configuracion Apache  
                            //    Nombre_ = "MySQL";//Nombre de la aplicacion

                            //    PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                            //    Puerto_ = LecturaPuerto.PrtMySQL;
                            //    Lista_Iniciado[0] = "MySQL";
                            //    Lista_Iniciado[1] = MiProceso.Id.ToString();
                            //    Lista_Iniciado[2] = LecturaPuerto.PrtMySQL;//rescantado la el puerto del apache 
                            //    Lista_Iniciado[3] = "Iniciado";
                            //    Lista_Iniciado[4] = "mysqld";//asignamos el nombre del archivo Ejecutable 
                            //    AplicacionIniciado Init = Iniciado;
                            //    if (Init != null)
                            //    {
                            //        Init(this, Lista_Iniciado);
                            //    }
                            //    if (MiProceso.Start())//verificamos si el proceso se ha iniciado
                            //    {
                            //        Proceso_ = "Iniciado";
                            //        Valor_Iniciado = true;
                            //    }
                            //    else
                            //    {
                            //        Proceso_ = "No iniciado";
                            //        Valor_Iniciado = false;
                            //    }
                            //}
                            #endregion
                        }
                        catch (Exception dd)
                        { }
                        
                        #endregion

                        break;
                    case "mongod":
                        #region "Mongo DB"
                         Procesar.FileName = InformacionArc.FullName;
                         Procesar.WindowStyle = ProcessWindowStyle.Minimized;
                        RutaDBMongo ruta = new RutaDBMongo(RutaDBMongo.OpcionRuta.Leer); //obtien la rata donde se almacena la BD
                        Procesar.Arguments = "--dbpath " + ruta.RutaDB;
                        MiProceso = Process.Start(Procesar);
                         Thread.Sleep(2000);
                        if (ComprobarApli(Nombre_Recuperado) == true) {
                             Nombre_ = "MongoDB";//Nombre de la aplicacion
                            PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                            Puerto_ = LecturaPuerto.PrtMongoDB.TrimEnd(null);
                            Lista_Iniciado[0] = "MongoDB";
                            Lista_Iniciado[1] = MiProceso.Id.ToString();
                            Lista_Iniciado[2] = "27017";//rescantado la
                            Lista_Iniciado[3] = "Iniciado";
                            Lista_Iniciado[4] = "mongod";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "1";
                            //Lanza el evento
                            AplicacionIniciado Init = Iniciado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }else{
                            Lista_Iniciado[0] = "MongoDB";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = "0";
                            Lista_Iniciado[2] = "0";//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "No iniciado";
                            Lista_Iniciado[4] = "mongod";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                            AplicaionParado Init = Parado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                      #region "Algoritmo Antiguo"
                        //if (Buscar(Nombre_Recuperado) == true)
                        //{
                        //    //si existe la aplicacion Ejecutandose entonces suelta el evento
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    //_____________________________________________________________
                        //}
                        //else
                        //{

                        //    MiProceso = Process.Start(Procesar);
                        //    Thread.Sleep(1000); 
                        //    Nombre_ = "MongoDB";//Nombre de la aplicacion
                        //    PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                        //    Puerto_ = LecturaPuerto.PrtMongoDB ;
                        //    Lista_Iniciado[0] = "MongoDB";
                        //    Lista_Iniciado[1] = MiProceso.Id.ToString();
                        //    Lista_Iniciado[2] = "27017";//rescantado la
                        //    Lista_Iniciado[3] = "Iniciado";
                        //    Lista_Iniciado[4] = "MongoDB";//asignamos el nombre del archivo Ejecutable 
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //if (MiProceso.Start())//verificamos si el proceso se ha iniciado
                        //{
                        //    Proceso_ = "Iniciado";
                        //    Valor_Iniciado = true;

                        //}
                        //else
                        //{
                        //    Proceso_ = "No iniciado";
                        //    Valor_Iniciado = false;

                        //}
                        //}
                      #endregion 

                        #endregion 
                        break;
                    case "FileZilla Server":
                        #region "FileZilla"
                        Procesar.FileName = InformacionArc.FullName;
                        //Procesar.WindowStyle = ProcessWindowStyle.Hidden;
                        Procesar.Arguments = "-compat -start";
                         MiProceso = Process.Start(Procesar);
                        //Thread.Sleep(2000);
                        if (ComprobarApli(Nombre_Recuperado) == true)
                        {
                            LecturaPuerto.LeerFilezilla();//lee la configuracion Apache  
                            Nombre_ = "FileZilla";//Nombre de la aplicacion
                            PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                            Puerto_ = LecturaPuerto.PrtFiliZilla;
                            Lista_Iniciado[0] = "FileZilla";
                            Lista_Iniciado[1] = MiProceso.Id.ToString();
                            Lista_Iniciado[2] = LecturaPuerto.PrtFiliZilla;//rescantado la el puerto del apache
                            Lista_Iniciado[3] = "Iniciado";
                            Lista_Iniciado[4] = "FileZilla";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "1";
                            //Lanza el evento
                            AplicacionIniciado Init = Iniciado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                        else {
                            Lista_Iniciado[0] = "FileZilla";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = "0";
                            Lista_Iniciado[2] = "0";//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "No iniciado";
                            Lista_Iniciado[4] = "FileZilla";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                            AplicaionParado Init = Parado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                      #region "Algoritmo antiguo"
                        ////Procesar.Arguments = "--standalone";
                        //if (Buscar(Nombre_Recuperado) == true)
                        //{
                        //    //si existe la aplicacion Ejecutandose entonces suelta el evento
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    //_____________________________________________________________
                        //}
                        //else
                        //{

                        //    MiProceso = Process.Start(Procesar);
                        //    Thread.Sleep(1000);
                        //    LecturaPuerto.LeerFilezilla();//lee la configuracion Apache  
                        //    Nombre_ = "FileZilla";//Nombre de la aplicacion

                        //    PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                        //    Puerto_ = LecturaPuerto.PrtFiliZilla;
                        //    Lista_Iniciado[0] = "FileZilla";
                        //    Lista_Iniciado[1] = MiProceso.Id.ToString();
                        //    Lista_Iniciado[2] = LecturaPuerto.PrtFiliZilla;//rescantado la el puerto del apache
                        //    Lista_Iniciado[3] = "Iniciado";
                        //    Lista_Iniciado[4] = "FileZilla";//asignamos el nombre del archivo Ejecutable 
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    if (MiProceso.Start())//verificamos si el proceso se ha iniciado
                        //    {
                        //        Proceso_ = "Iniciado";
                        //        Valor_Iniciado = true;

                        //    }
                        //    else
                        //    {
                        //        Proceso_ = "No iniciado";
                        //        Valor_Iniciado = false;

                        //    }
                        //}
                      #endregion
                        #endregion
                        break;
                    case "mercury":

                        #region "Mercury"
                        Procesar.FileName = InformacionArc.FullName;
                        Procesar.WindowStyle = ProcessWindowStyle.Hidden;
                          MiProceso = Process.Start(Procesar);
                       // Thread.Sleep(2000);
                        if (ComprobarApli(Nombre_Recuperado) == true)
                        {
                            LecturaPuerto.LeerMercury();//lee la configuracion Mercury  
                            Nombre_ = "Mercury";//Nombre de la aplicacio
                            PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                            Puerto_ = LecturaPuerto.PrtMercury;
                            Lista_Iniciado[0] = "Mercury";
                            Lista_Iniciado[1] = MiProceso.Id.ToString();
                            Lista_Iniciado[2] = LecturaPuerto.PrtMercury.TrimEnd();//rescantado la el puerto del Mercury
                            Lista_Iniciado[3] = "Iniciado";
                            Lista_Iniciado[4] = "Mercury";//asignamos el nombre del archivo Ejecutable
                            Lista_Iniciado[5] = "1";
                            //Lanza el evento
                            AplicacionIniciado Init = Iniciado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                        else
                        {
                            Lista_Iniciado[0] = "Mercury";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = "0";
                            Lista_Iniciado[2] = "0";//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "No iniciado";
                            Lista_Iniciado[4] = "Mercury";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                            AplicaionParado Init = Parado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                     #region "Codigo antiguo"
                        //if (Buscar(Nombre_Recuperado) == true)
                        //{
                        //    //si existe la aplicacion Ejecutandose entonces suelta el evento
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    //_____________________________________________________________
                        //}
                        //else
                        //{

                        //    MiProceso = Process.Start(Procesar);
                        //    LecturaPuerto.LeerMercury() ;//lee la configuracion Mercury  
                        //    Nombre_ = "Mercury";//Nombre de la aplicacio
                        //    PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                        //    Puerto_ = LecturaPuerto.PrtMercury;
                        //    Lista_Iniciado[0] = "Mercury";
                        //    Lista_Iniciado[1] = MiProceso.Id.ToString();
                        //    Lista_Iniciado[2] = LecturaPuerto.PrtMercury;//rescantado la el puerto del Mercury
                        //    Lista_Iniciado[3] = "Iniciado";
                        //    Lista_Iniciado[4] = "Mercury";//asignamos el nombre del archivo Ejecutable 
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //}
                     #endregion
                        
                        #endregion
                        break;
                    case "catalina_start":

                        #region "Tomcat" 
                        Procesar.WorkingDirectory = InformacionArc.Directory.ToString();
                        Procesar.WindowStyle = ProcessWindowStyle.Minimized;
                        //Procesar.FileName = InformacionArc.FullName; 
                        Procesar.FileName = "catalina_start.bat";
                           MiProceso = Process.Start(Procesar);
                        Thread.Sleep(9000);
                        if (ComprobarApli("java") == true)
                        {
                            LecturaPuerto.LeerTomcat();//lee la configuracion tomcat  
                            Nombre_ = "Tomcat";//Nombre de la aplicacion
                            PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                            Puerto_ = LecturaPuerto.PrtTomcat;
                            Lista_Iniciado[0] = "Apache";
                            Lista_Iniciado[1] = MiProceso.Id.ToString();
                            Lista_Iniciado[2] = LecturaPuerto.PrtTomcat;//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "Iniciado";
                            Lista_Iniciado[4] = "Tomcat";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "1";
                            //Lanza el evento
                            AplicacionIniciado Init = Iniciado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                        else {
                            Lista_Iniciado[0] = "Tomcat";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = "0";
                            Lista_Iniciado[2] = "0";//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "No iniciado";
                            Lista_Iniciado[4] = "Tomcat";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                            AplicaionParado Init = Parado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }

                       #region "Codigo Antiguo"
                        //if (Buscar("java") == true) {

                        //    //si existe la aplicacion Ejecutandose entonces suelta el evento
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    //_____________________________________________________________
                        //}
                        //else
                        //{

                        //    MiProceso = Process.Start(Procesar);
                        //    LecturaPuerto.LeerTomcat();//lee la configuracion tomcat  
                        //    Nombre_ = "Tomcat";//Nombre de la aplicacion

                        //    PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                        //    Puerto_ = LecturaPuerto.PrtTomcat;
                        //    Lista_Iniciado[0] = "Apache";
                        //    Lista_Iniciado[1] = MiProceso.Id.ToString();
                        //    Lista_Iniciado[2] = LecturaPuerto.PrtTomcat;//rescantado la el puerto del apache 
                        //    Lista_Iniciado[3] = "Iniciado";
                        //    Lista_Iniciado[4] = "Tomcat";//asignamos el nombre del archivo Ejecutable 
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }

                        //    Proceso_ = "Iniciado";
                        //    Valor_Iniciado = true;

                        //}
                     #endregion
                        
                      
#endregion

                        break;
                    case "mailserver":
                       #region "Argosoft"
                        Procesar.FileName = InformacionArc.FullName;
                        //Procesar.WindowStyle = ProcessWindowStyle.Hidden;
                        MiProceso = Process.Start(Procesar);
                        //Thread.Sleep(2000);
                        if (ComprobarApli(Nombre_Recuperado) == true) {
                            LecturaPuerto.LeerArgosoft();//lee la configuracion Mercury  
                            Nombre_ = "ArgoSoftMail";//Nombre de la aplicacio
                            PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                            Puerto_ = LecturaPuerto.PrtArgosoft;
                            Lista_Iniciado[0] = "ArgoSoftMail";
                            Lista_Iniciado[1] = MiProceso.Id.ToString();
                            Lista_Iniciado[2] = LecturaPuerto.PrtArgosoft;//rescantado la el puerto del Mercury
                            Lista_Iniciado[3] = "Iniciado";
                            Lista_Iniciado[4] = "ArgoSoftMail";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "1";
                            //Lanza el evento
                            AplicacionIniciado Init = Iniciado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                        else {
                            Lista_Iniciado[0] = "ArgoSoftMail";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = "0";
                            Lista_Iniciado[2] = "0";//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "No iniciado";
                            Lista_Iniciado[4] = "ArgoSoftMail";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                            AplicaionParado Init = Parado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                        #region "Codigo antiguo"
                        //if (Buscar(Nombre_Recuperado) == true)
                        //{
                        //    //si existe la aplicacion Ejecutandose entonces suelta el evento
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    //_____________________________________________________________
                        //}
                        //else
                        //{

                        //    MiProceso = Process.Start(Procesar);
                        //    LecturaPuerto.LeerArgosoft() ;//lee la configuracion Mercury  
                        //    Nombre_ = "ArgoSoftMail";//Nombre de la aplicacio
                        //    PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                        //    Puerto_ = LecturaPuerto.PrtArgosoft ;
                        //    Lista_Iniciado[0] = "ArgoSoftMail";
                        //    Lista_Iniciado[1] = MiProceso.Id.ToString();
                        //    Lista_Iniciado[2] = LecturaPuerto.PrtArgosoft ;//rescantado la el puerto del Mercury
                        //    Lista_Iniciado[3] = "Iniciado";
                        //    Lista_Iniciado[4] = "ArgoSoftMail";//asignamos el nombre del archivo Ejecutable 
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //}
                        #endregion 
                       #endregion
                        break;
                    case "pg_ctl":
                           
                        #region "PostgreSql"
                        Procesar.FileName = InformacionArc.FullName;
                        Procesar.Arguments = "-D " + Application.StartupPath + @"\Programas\PostGreSQL\data" + " -l logfile start";//argumentos para ejecutar la aplicacion
                        //pg_ctl -D F:\PostGre\data -l logfile start
                        Procesar.WindowStyle = ProcessWindowStyle.Hidden;
                        MiProceso = Process.Start(Procesar);
                       // Thread.Sleep(2000);
                        if (ComprobarApli("postgres") == true)
                        {
                            LecturaPuerto.LeerPostgreSQL();//lee la configuracion Mercury  
                            Nombre_ = "PostgreSQL";//Nombre de la aplicacio
                            PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                            Puerto_ = LecturaPuerto.PrtPostgreSQL;
                            Lista_Iniciado[0] = "PostgreSQL";
                            Lista_Iniciado[1] = MiProceso.Id.ToString();
                            Lista_Iniciado[2] = LecturaPuerto.PrtPostgreSQL;//rescantado la el puerto del Mercury
                            Lista_Iniciado[3] = "Iniciado";
                            Lista_Iniciado[4] = "PostgreSQL";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "1";
                            //Lanza el evento
                            AplicacionIniciado Init = Iniciado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                        else {
                            Lista_Iniciado[0] = "PostgreSQL";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = "0";
                            Lista_Iniciado[2] = "0";//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "No iniciado";
                            Lista_Iniciado[4] = "PostgreSQL";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                            AplicaionParado Init = Parado;
                            if (Init != null)
                            {
                                Init(this, Lista_Iniciado);
                            }
                        }
                        //if (Buscar(Nombre_Recuperado) == true)
                        //{
                        //    //si existe la aplicacion Ejecutandose entonces suelta el evento
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //    //_____________________________________________________________
                        //}
                        //else
                        //{

                        //    MiProceso = Process.Start(Procesar);
                        //    LecturaPuerto.LeerPostgreSQL ();//lee la configuracion Mercury  
                        //    Nombre_ = "PostgreSQL";//Nombre de la aplicacio
                        //    PID_ = MiProceso.Id.ToString(); //Asigacion de PID
                        //    Puerto_ = LecturaPuerto.PrtPostgreSQL ;
                        //    Lista_Iniciado[0] = "PostgreSQL";
                        //    Lista_Iniciado[1] = MiProceso.Id.ToString();
                        //    Lista_Iniciado[2] = LecturaPuerto.PrtPostgreSQL ;//rescantado la el puerto del Mercury
                        //    Lista_Iniciado[3] = "Iniciado";
                        //    Lista_Iniciado[4] = "PostgreSQL";//asignamos el nombre del archivo Ejecutable 
                        //    AplicacionIniciado Init = Iniciado;
                        //    if (Init != null)
                        //    {
                        //        Init(this, Lista_Iniciado);
                        //    }
                        //}

                        #endregion
                        break; 

                }
               
            
            }else {
              
                MessageBox.Show("Error la aplicacion no existe", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
       
         }
         /// <summary>
         /// Metodo  para cancelar la ejecucion de la aplicacion
         /// </summary>
         /// <param name="Nombre"></param>
         /// <param name="Opcion"></param>
        public  void Parar(string Nombre, close Opcion)
         {
             foreach (Process list in Process.GetProcesses())
             {
                 if (list.ProcessName == Nombre)
                 {
                     try
                     {
                         if (Opcion == close.noting) {
                             list.Kill();
                             list.WaitForExit();
                             switch (Nombre){
                            case "httpd":
                            Lista_Iniciado[0] = "Apache";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = list.Id.ToString();
                            LecturaPuerto.LeerConfigApache();
                            Lista_Iniciado[2] = LecturaPuerto.PrtApache;//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "Parado";
                            Lista_Iniciado[4] = Nombres_Apli[0];//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                            break; 
                                case "mysqld":
                                Lista_Iniciado[0] = "MySQL";//Nombre de la aplicacion 
                                Lista_Iniciado[1] = list.Id.ToString();
                                LecturaPuerto.LeerIniMysql();
                                Lista_Iniciado[2] = LecturaPuerto.PrtMySQL;//rescantado la el puerto del mysql 
                                Lista_Iniciado[3] = "Parado";
                                Lista_Iniciado[4] = "mysqld";//asignamos el nombre del archivo Ejecutable 
                                Lista_Iniciado[5] = "0";
                                 break;
                                    case "FileZilla Server":
                                     Lista_Iniciado[0] = "FileZilla";//Nombre de la aplicacion 
                                     Lista_Iniciado[1] = list.Id.ToString();
                                     LecturaPuerto.LeerFilezilla();
                                     Lista_Iniciado[2] = LecturaPuerto.PrtFiliZilla;//rescantado la el puerto del filezilla 
                                     Lista_Iniciado[3] = "Parado";
                                     Lista_Iniciado[4] = "FileZilla";//asignamos el nombre del archivo Ejecutable 
                                     Lista_Iniciado[5] = "0";
                                     break;
                                    case "mercury":
                                             Lista_Iniciado[0] = "Mercury";//Nombre de la aplicacion 
                                             Lista_Iniciado[1] = list.Id.ToString();
                                             LecturaPuerto.LeerMercury();
                                             Lista_Iniciado[2] = LecturaPuerto.PrtMercury;//rescantado la el puerto del filezilla 
                                             Lista_Iniciado[3] = "Parado";
                                             Lista_Iniciado[4] = "Mercury";//asignamos el nombre del archivo Ejecutable 
                                             Lista_Iniciado[5] = "0";
                                       break;
                                            case "java":
                                               Lista_Iniciado[0] = "Tomcat";//Nombre de la aplicacion 
                                               Lista_Iniciado[1] = list.Id.ToString();
                                               LecturaPuerto.LeerTomcat();
                                               Lista_Iniciado[2] = LecturaPuerto.PrtTomcat;//rescantado la el puerto del filezilla 
                                               Lista_Iniciado[3] = "Parado";
                                               Lista_Iniciado[4] = "Tomcat";//asignamos el nombre del archivo Ejecutable 
                                               Lista_Iniciado[5] = "0";
                                               break;
                                            case "mailserver":
                                                       Lista_Iniciado[0] = "ArgoSoftMail";//Nombre de la aplicacion 
                                                       Lista_Iniciado[1] = list.Id.ToString();
                                                       LecturaPuerto.LeerArgosoft();
                                                       Lista_Iniciado[2] = LecturaPuerto.PrtArgosoft;//rescantado la el puerto del filezilla 
                                                       Lista_Iniciado[3] = "Parado";
                                                       Lista_Iniciado[4] = "ArgoSoftMail";//asignamos el nombre del archivo Ejecutable 
                                                       Lista_Iniciado[5] = "0";
                                                       break;
                                                                    case "postgres":
                                                                       Lista_Iniciado[0] = "PostgreSQL";//Nombre de la aplicacion 
                                                                       Lista_Iniciado[1] = list.Id.ToString();
                                                                       LecturaPuerto.LeerPostgreSQL();
                                                                       Lista_Iniciado[2] = LecturaPuerto.PrtPostgreSQL;//rescantado la el puerto del filezilla 
                                                                       Lista_Iniciado[3] = "Parado";
                                                                       Lista_Iniciado[4] = "PostgreSQL";//asignamos el nombre del archivo Ejecutable 
                                                                       Lista_Iniciado[5] = "0";
                                                                       break;
                             } 
                             AplicaionParado Init = Parado;
                             if (Init != null)
                             {
                                 Init(this, Lista_Iniciado);
                             }
                         }
                         else {
                           
                             list.CloseMainWindow();
                             
                             switch (Nombre)
                             {
                                 case "mongod":
                            Lista_Iniciado[0] = "MongoDB";//Nombre de la aplicacion 
                            Lista_Iniciado[1] = list.Id.ToString();
                            Lista_Iniciado[2] = LecturaPuerto.PrtMongoDB ;//rescantado la el puerto del apache 
                            Lista_Iniciado[3] = "Parado";
                            Lista_Iniciado[4] = "mongod";//asignamos el nombre del archivo Ejecutable 
                            Lista_Iniciado[5] = "0";
                              AplicaionParado Init = Parado;
                             if (Init != null)
                             {
                                 Init(this, Lista_Iniciado);
                             }
                                     break;
                             }
                             list.Close();
                         }
                                                 
                     }
                     catch (Exception d)
                     {
                         MessageBox.Show("Sucito grave error","Error",MessageBoxButtons.OK ,MessageBoxIcon.Error   ); 
                     }
                 }
             }
 
         }

       public    ArrayList ProgEjecut
         {
             get { return Aplicaciones_ ; }
         }

         /// <summary>
         /// Devuelve el nombre del proceso  de la aplicacion
         /// </summary>
       public String Nombre {
           get { return Nombre_; } 
       }

         /// <summary>
         /// Devuelve PID de la aplicacion
         /// </summary>
       public String PID {
           get { return PID_; } 
       }
         /// <summary>
         /// Devuel puerto del servidor
         /// </summary>
       public String Puerto {
           get { return Puerto_; } 
       }
         /// <summary>
         /// Devuelve el mensaje del proceso
         /// </summary>
       public String Proceso {
           get { return Proceso_; } 
       }
         /// <summary>
         /// Devuelve un valor booleano sobre informacion ejecutado
         /// </summary>
       public bool ValorInciado {
           get { return Valor_Iniciado; } 
       }


      
     }



}