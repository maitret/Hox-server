﻿namespace Hox
{
    partial class FmrHox
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
        	this.components = new System.ComponentModel.Container();
        	System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FmrHox));
        	System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
			"Apache",
			"",
			"",
			""}, 0);
        	System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
			"Tomcat",
			"",
			"",
			""}, 6);
        	System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
			"MySQL",
			"",
			"",
			""}, 1);
        	System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
			"MongoDB",
			"",
			"",
			""}, 9);
        	System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
			"PostgreSQL",
			"",
			"",
			""}, 8);
        	System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new string[] {
			"FileZilla",
			"",
			"",
			""}, 4);
        	System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem(new string[] {
			"Mercury",
			"",
			"",
			""}, 5);
        	System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem(new string[] {
			"ArgoSoftMail",
			"",
			"",
			""}, 7);
        	this.imageList1 = new System.Windows.Forms.ImageList(this.components);
        	this.statusStrip1 = new System.Windows.Forms.StatusStrip();
        	this.menuStrip1 = new System.Windows.Forms.MenuStrip();
        	this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        	this.apcheToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.apacheconfToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.phatToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        	this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.mySQLINIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.phatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.pHPToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
        	this.pHPINIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.PHPubicaciónToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        	this.pHPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.fileZillaServerInterfaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.fileZillaServerXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.phatToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
        	this.mercuryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        	this.MerStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
        	this.MerINIStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
        	this.ubiMerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.tomcatToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        	this.TomserverXMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.TomubicaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.postGreSQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.INIPostgre = new System.Windows.Forms.ToolStripMenuItem();
        	this.UbiPostgre = new System.Windows.Forms.ToolStripMenuItem();
        	this.mongoDBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.rutaDeDBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.ubicacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.pHPMYADMINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.HostAlterToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        	this.RutaMogo = new System.Windows.Forms.ToolStripMenuItem();
        	this.editoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.pHPToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
        	this.mySQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.sobreEsteProgramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.httpwwwworlcomcomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.OpcionNavegacion = new System.Windows.Forms.ContextMenuStrip(this.components);
        	this.ApacheWeb = new System.Windows.Forms.ToolStripMenuItem();
        	this.TomcatWeb = new System.Windows.Forms.ToolStripMenuItem();
        	this.ArgoSoftWeb = new System.Windows.Forms.ToolStripMenuItem();
        	this.OpcionPHP = new System.Windows.Forms.ContextMenuStrip(this.components);
        	this.ItemPhpPhat = new System.Windows.Forms.ToolStripMenuItem();
        	this.ItemPHPINI = new System.Windows.Forms.ToolStripMenuItem();
        	this.ItemConVisualPHP = new System.Windows.Forms.ToolStripMenuItem();
        	this.listView1 = new System.Windows.Forms.ListView();
        	this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
        	this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
        	this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
        	this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
        	this.button3 = new System.Windows.Forms.Button();
        	this.pictureBox1 = new System.Windows.Forms.PictureBox();
        	this.BtnTomc = new System.Windows.Forms.Button();
        	this.BtbMon = new System.Windows.Forms.Button();
        	this.button1 = new System.Windows.Forms.Button();
        	this.button2 = new System.Windows.Forms.Button();
        	this.BtnPostGre = new System.Windows.Forms.Button();
        	this.PHPbtn = new System.Windows.Forms.Button();
        	this.BtnExplorador = new System.Windows.Forms.Button();
        	this.PhMyAminbnt = new System.Windows.Forms.Button();
        	this.button8 = new System.Windows.Forms.Button();
        	this.button7 = new System.Windows.Forms.Button();
        	this.button12 = new System.Windows.Forms.Button();
        	this.button11 = new System.Windows.Forms.Button();
        	this.button10 = new System.Windows.Forms.Button();
        	this.button9 = new System.Windows.Forms.Button();
        	this.BtbMysql = new System.Windows.Forms.Button();
        	this.BtnApache = new System.Windows.Forms.Button();
        	this.BtbArg = new System.Windows.Forms.Button();
        	this.BtnMer = new System.Windows.Forms.Button();
        	this.BtnFil = new System.Windows.Forms.Button();
        	this.versionDePHPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        	this.menuStrip1.SuspendLayout();
        	this.OpcionNavegacion.SuspendLayout();
        	this.OpcionPHP.SuspendLayout();
        	((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
        	this.SuspendLayout();
        	// 
        	// imageList1
        	// 
        	this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
        	this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
        	this.imageList1.Images.SetKeyName(0, "apche.png");
        	this.imageList1.Images.SetKeyName(1, "Sin título-1.png");
        	this.imageList1.Images.SetKeyName(2, "mysql.png");
        	this.imageList1.Images.SetKeyName(3, "hat.png");
        	this.imageList1.Images.SetKeyName(4, "fff.png");
        	this.imageList1.Images.SetKeyName(5, "g.png");
        	this.imageList1.Images.SetKeyName(6, "tomcat.png");
        	this.imageList1.Images.SetKeyName(7, "argo.png");
        	this.imageList1.Images.SetKeyName(8, "postrgre.png");
        	this.imageList1.Images.SetKeyName(9, "mongo.png");
        	// 
        	// statusStrip1
        	// 
        	this.statusStrip1.Location = new System.Drawing.Point(0, 548);
        	this.statusStrip1.Name = "statusStrip1";
        	this.statusStrip1.Size = new System.Drawing.Size(671, 22);
        	this.statusStrip1.TabIndex = 10;
        	this.statusStrip1.Text = "statusStrip1";
        	// 
        	// menuStrip1
        	// 
        	this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
        	this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.toolStripMenuItem1,
			this.pHPMYADMINToolStripMenuItem,
			this.editoresToolStripMenuItem,
			this.ayudaToolStripMenuItem});
        	this.menuStrip1.Location = new System.Drawing.Point(0, 0);
        	this.menuStrip1.Name = "menuStrip1";
        	this.menuStrip1.Size = new System.Drawing.Size(671, 24);
        	this.menuStrip1.TabIndex = 12;
        	this.menuStrip1.Text = "menuStrip1";
        	// 
        	// toolStripMenuItem1
        	// 
        	this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.apcheToolStripMenuItem,
			this.archivoToolStripMenuItem,
			this.pHPToolStripMenuItem3,
			this.pHPToolStripMenuItem,
			this.mercuryToolStripMenuItem1,
			this.tomcatToolStripMenuItem1,
			this.postGreSQLToolStripMenuItem,
			this.mongoDBToolStripMenuItem});
        	this.toolStripMenuItem1.Name = "toolStripMenuItem1";
        	this.toolStripMenuItem1.Size = new System.Drawing.Size(95, 20);
        	this.toolStripMenuItem1.Text = "Configuracion";
        	// 
        	// apcheToolStripMenuItem
        	// 
        	this.apcheToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.apacheconfToolStripMenuItem,
			this.phatToolStripMenuItem1});
        	this.apcheToolStripMenuItem.Image = global::Hox.Properties.Resources._160px_ASF_f;
        	this.apcheToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
        	this.apcheToolStripMenuItem.Name = "apcheToolStripMenuItem";
        	this.apcheToolStripMenuItem.Size = new System.Drawing.Size(168, 54);
        	this.apcheToolStripMenuItem.Text = "Apche";
        	// 
        	// apacheconfToolStripMenuItem
        	// 
        	this.apacheconfToolStripMenuItem.Name = "apacheconfToolStripMenuItem";
        	this.apacheconfToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
        	this.apacheconfToolStripMenuItem.Text = "Apache (conf)";
        	// 
        	// phatToolStripMenuItem1
        	// 
        	this.phatToolStripMenuItem1.Name = "phatToolStripMenuItem1";
        	this.phatToolStripMenuItem1.Size = new System.Drawing.Size(149, 22);
        	this.phatToolStripMenuItem1.Text = "Ubicación";
        	// 
        	// archivoToolStripMenuItem
        	// 
        	this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.mySQLINIToolStripMenuItem,
			this.phatToolStripMenuItem});
        	this.archivoToolStripMenuItem.Image = global::Hox.Properties.Resources._50px_Mysql;
        	this.archivoToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
        	this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
        	this.archivoToolStripMenuItem.Size = new System.Drawing.Size(168, 54);
        	this.archivoToolStripMenuItem.Text = "Mysql";
        	// 
        	// mySQLINIToolStripMenuItem
        	// 
        	this.mySQLINIToolStripMenuItem.Name = "mySQLINIToolStripMenuItem";
        	this.mySQLINIToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
        	this.mySQLINIToolStripMenuItem.Text = "MySQL (INI)";
        	// 
        	// phatToolStripMenuItem
        	// 
        	this.phatToolStripMenuItem.Name = "phatToolStripMenuItem";
        	this.phatToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
        	this.phatToolStripMenuItem.Text = "Ubicación";
        	// 
        	// pHPToolStripMenuItem3
        	// 
        	this.pHPToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.pHPINIToolStripMenuItem,
			this.PHPubicaciónToolStripMenuItem1});
        	this.pHPToolStripMenuItem3.Image = global::Hox.Properties.Resources._170px_PHP_logod;
        	this.pHPToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
        	this.pHPToolStripMenuItem3.Name = "pHPToolStripMenuItem3";
        	this.pHPToolStripMenuItem3.Size = new System.Drawing.Size(168, 54);
        	this.pHPToolStripMenuItem3.Text = "PHP";
        	// 
        	// pHPINIToolStripMenuItem
        	// 
        	this.pHPINIToolStripMenuItem.Name = "pHPINIToolStripMenuItem";
        	this.pHPINIToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
        	this.pHPINIToolStripMenuItem.Text = "PHP (INI)";
        	// 
        	// PHPubicaciónToolStripMenuItem1
        	// 
        	this.PHPubicaciónToolStripMenuItem1.Name = "PHPubicaciónToolStripMenuItem1";
        	this.PHPubicaciónToolStripMenuItem1.Size = new System.Drawing.Size(127, 22);
        	this.PHPubicaciónToolStripMenuItem1.Text = "Ubicación";
        	// 
        	// pHPToolStripMenuItem
        	// 
        	this.pHPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.fileZillaServerInterfaceToolStripMenuItem,
			this.fileZillaServerXMLToolStripMenuItem,
			this.phatToolStripMenuItem2});
        	this.pHPToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pHPToolStripMenuItem.Image")));
        	this.pHPToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
        	this.pHPToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
        	this.pHPToolStripMenuItem.Name = "pHPToolStripMenuItem";
        	this.pHPToolStripMenuItem.Size = new System.Drawing.Size(168, 54);
        	this.pHPToolStripMenuItem.Text = "FiliZilla";
        	// 
        	// fileZillaServerInterfaceToolStripMenuItem
        	// 
        	this.fileZillaServerInterfaceToolStripMenuItem.Name = "fileZillaServerInterfaceToolStripMenuItem";
        	this.fileZillaServerInterfaceToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
        	this.fileZillaServerInterfaceToolStripMenuItem.Text = "FileZilla Server Interface";
        	// 
        	// fileZillaServerXMLToolStripMenuItem
        	// 
        	this.fileZillaServerXMLToolStripMenuItem.Name = "fileZillaServerXMLToolStripMenuItem";
        	this.fileZillaServerXMLToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
        	this.fileZillaServerXMLToolStripMenuItem.Text = "FileZilla Server (XML)";
        	// 
        	// phatToolStripMenuItem2
        	// 
        	this.phatToolStripMenuItem2.Name = "phatToolStripMenuItem2";
        	this.phatToolStripMenuItem2.Size = new System.Drawing.Size(198, 22);
        	this.phatToolStripMenuItem2.Text = "Ubicación";
        	// 
        	// mercuryToolStripMenuItem1
        	// 
        	this.mercuryToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.MerStripMenuItem2,
			this.MerINIStripMenuItem3,
			this.ubiMerToolStripMenuItem});
        	this.mercuryToolStripMenuItem1.Image = global::Hox.Properties.Resources.g;
        	this.mercuryToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
        	this.mercuryToolStripMenuItem1.Name = "mercuryToolStripMenuItem1";
        	this.mercuryToolStripMenuItem1.Size = new System.Drawing.Size(168, 54);
        	this.mercuryToolStripMenuItem1.Text = "Mercury";
        	// 
        	// MerStripMenuItem2
        	// 
        	this.MerStripMenuItem2.Name = "MerStripMenuItem2";
        	this.MerStripMenuItem2.Size = new System.Drawing.Size(144, 22);
        	this.MerStripMenuItem2.Text = "Mercury";
        	// 
        	// MerINIStripMenuItem3
        	// 
        	this.MerINIStripMenuItem3.Name = "MerINIStripMenuItem3";
        	this.MerINIStripMenuItem3.Size = new System.Drawing.Size(144, 22);
        	this.MerINIStripMenuItem3.Text = "Mercury (INI)";
        	// 
        	// ubiMerToolStripMenuItem
        	// 
        	this.ubiMerToolStripMenuItem.Name = "ubiMerToolStripMenuItem";
        	this.ubiMerToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
        	this.ubiMerToolStripMenuItem.Text = "Ubicación";
        	// 
        	// tomcatToolStripMenuItem1
        	// 
        	this.tomcatToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.TomserverXMLToolStripMenuItem,
			this.TomubicaciónToolStripMenuItem});
        	this.tomcatToolStripMenuItem1.Image = global::Hox.Properties.Resources.tomcat;
        	this.tomcatToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
        	this.tomcatToolStripMenuItem1.Name = "tomcatToolStripMenuItem1";
        	this.tomcatToolStripMenuItem1.Size = new System.Drawing.Size(168, 54);
        	this.tomcatToolStripMenuItem1.Text = "Tomcat";
        	// 
        	// TomserverXMLToolStripMenuItem
        	// 
        	this.TomserverXMLToolStripMenuItem.Name = "TomserverXMLToolStripMenuItem";
        	this.TomserverXMLToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
        	this.TomserverXMLToolStripMenuItem.Text = "Server (XML)";
        	// 
        	// TomubicaciónToolStripMenuItem
        	// 
        	this.TomubicaciónToolStripMenuItem.Name = "TomubicaciónToolStripMenuItem";
        	this.TomubicaciónToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
        	this.TomubicaciónToolStripMenuItem.Text = "Ubicación";
        	// 
        	// postGreSQLToolStripMenuItem
        	// 
        	this.postGreSQLToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.INIPostgre,
			this.UbiPostgre});
        	this.postGreSQLToolStripMenuItem.Image = global::Hox.Properties.Resources.Untitled1;
        	this.postGreSQLToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
        	this.postGreSQLToolStripMenuItem.Name = "postGreSQLToolStripMenuItem";
        	this.postGreSQLToolStripMenuItem.Size = new System.Drawing.Size(168, 54);
        	this.postGreSQLToolStripMenuItem.Text = "PostGreSQL";
        	// 
        	// INIPostgre
        	// 
        	this.INIPostgre.Name = "INIPostgre";
        	this.INIPostgre.Size = new System.Drawing.Size(153, 22);
        	this.INIPostgre.Text = "Archivo (conf) ";
        	// 
        	// UbiPostgre
        	// 
        	this.UbiPostgre.Name = "UbiPostgre";
        	this.UbiPostgre.Size = new System.Drawing.Size(153, 22);
        	this.UbiPostgre.Text = "Ubicación";
        	// 
        	// mongoDBToolStripMenuItem
        	// 
        	this.mongoDBToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.rutaDeDBToolStripMenuItem,
			this.ubicacionToolStripMenuItem});
        	this.mongoDBToolStripMenuItem.Image = global::Hox.Properties.Resources.mongo;
        	this.mongoDBToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
        	this.mongoDBToolStripMenuItem.Name = "mongoDBToolStripMenuItem";
        	this.mongoDBToolStripMenuItem.Size = new System.Drawing.Size(168, 54);
        	this.mongoDBToolStripMenuItem.Text = "MongoDB";
        	// 
        	// rutaDeDBToolStripMenuItem
        	// 
        	this.rutaDeDBToolStripMenuItem.Name = "rutaDeDBToolStripMenuItem";
        	this.rutaDeDBToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
        	this.rutaDeDBToolStripMenuItem.Text = "Ruta de DB";
        	// 
        	// ubicacionToolStripMenuItem
        	// 
        	this.ubicacionToolStripMenuItem.Name = "ubicacionToolStripMenuItem";
        	this.ubicacionToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
        	this.ubicacionToolStripMenuItem.Text = "Ubicacion";
        	// 
        	// pHPMYADMINToolStripMenuItem
        	// 
        	this.pHPMYADMINToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.HostAlterToolStripMenuItem1,
			this.RutaMogo});
        	this.pHPMYADMINToolStripMenuItem.Name = "pHPMYADMINToolStripMenuItem";
        	this.pHPMYADMINToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
        	this.pHPMYADMINToolStripMenuItem.Text = "Opciones";
        	// 
        	// HostAlterToolStripMenuItem1
        	// 
        	this.HostAlterToolStripMenuItem1.Name = "HostAlterToolStripMenuItem1";
        	this.HostAlterToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
        	this.HostAlterToolStripMenuItem1.Text = "Dominios";
        	// 
        	// RutaMogo
        	// 
        	this.RutaMogo.Name = "RutaMogo";
        	this.RutaMogo.Size = new System.Drawing.Size(155, 22);
        	this.RutaMogo.Text = "Ruta MongoDB";
        	// 
        	// editoresToolStripMenuItem
        	// 
        	this.editoresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.pHPToolStripMenuItem1,
			this.mySQLToolStripMenuItem});
        	this.editoresToolStripMenuItem.Name = "editoresToolStripMenuItem";
        	this.editoresToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
        	this.editoresToolStripMenuItem.Text = "Herramientas";
        	// 
        	// pHPToolStripMenuItem1
        	// 
        	this.pHPToolStripMenuItem1.Name = "pHPToolStripMenuItem1";
        	this.pHPToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
        	this.pHPToolStripMenuItem1.Text = "HoxEditor";
        	this.pHPToolStripMenuItem1.Visible = false;
        	// 
        	// mySQLToolStripMenuItem
        	// 
        	this.mySQLToolStripMenuItem.Name = "mySQLToolStripMenuItem";
        	this.mySQLToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
        	this.mySQLToolStripMenuItem.Text = "HoxConectSQL";
        	this.mySQLToolStripMenuItem.Visible = false;
        	// 
        	// ayudaToolStripMenuItem
        	// 
        	this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.sobreEsteProgramaToolStripMenuItem,
			this.httpwwwworlcomcomToolStripMenuItem});
        	this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
        	this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
        	this.ayudaToolStripMenuItem.Text = "Ayuda";
        	// 
        	// sobreEsteProgramaToolStripMenuItem
        	// 
        	this.sobreEsteProgramaToolStripMenuItem.Name = "sobreEsteProgramaToolStripMenuItem";
        	this.sobreEsteProgramaToolStripMenuItem.Size = new System.Drawing.Size(251, 22);
        	this.sobreEsteProgramaToolStripMenuItem.Text = "Sobre este programa";
        	// 
        	// httpwwwworlcomcomToolStripMenuItem
        	// 
        	this.httpwwwworlcomcomToolStripMenuItem.Name = "httpwwwworlcomcomToolStripMenuItem";
        	this.httpwwwworlcomcomToolStripMenuItem.Size = new System.Drawing.Size(251, 22);
        	this.httpwwwworlcomcomToolStripMenuItem.Text = "http://www.hoxserver.asqki.com/";
        	this.httpwwwworlcomcomToolStripMenuItem.Click += new System.EventHandler(this.HttpwwwworlcomcomToolStripMenuItemClick);
        	// 
        	// OpcionNavegacion
        	// 
        	this.OpcionNavegacion.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.ApacheWeb,
			this.TomcatWeb,
			this.ArgoSoftWeb});
        	this.OpcionNavegacion.Name = "OpcionNavegacion";
        	this.OpcionNavegacion.Size = new System.Drawing.Size(204, 70);
        	// 
        	// ApacheWeb
        	// 
        	this.ApacheWeb.Image = global::Hox.Properties.Resources.resultset_next;
        	this.ApacheWeb.Name = "ApacheWeb";
        	this.ApacheWeb.Size = new System.Drawing.Size(203, 22);
        	this.ApacheWeb.Text = "Apache (localhost)";
        	// 
        	// TomcatWeb
        	// 
        	this.TomcatWeb.Image = global::Hox.Properties.Resources.resultset_next;
        	this.TomcatWeb.Name = "TomcatWeb";
        	this.TomcatWeb.Size = new System.Drawing.Size(203, 22);
        	this.TomcatWeb.Text = "Tomcat (localhost)";
        	// 
        	// ArgoSoftWeb
        	// 
        	this.ArgoSoftWeb.Image = global::Hox.Properties.Resources.resultset_next;
        	this.ArgoSoftWeb.Name = "ArgoSoftWeb";
        	this.ArgoSoftWeb.Size = new System.Drawing.Size(203, 22);
        	this.ArgoSoftWeb.Text = "ArgoSoftMail (localhost)";
        	// 
        	// OpcionPHP
        	// 
        	this.OpcionPHP.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.versionDePHPToolStripMenuItem,
			this.ItemPhpPhat,
			this.ItemPHPINI,
			this.ItemConVisualPHP});
        	this.OpcionPHP.Name = "OpcionNavegacion";
        	this.OpcionPHP.Size = new System.Drawing.Size(177, 92);
        	// 
        	// ItemPhpPhat
        	// 
        	this.ItemPhpPhat.Name = "ItemPhpPhat";
        	this.ItemPhpPhat.Size = new System.Drawing.Size(176, 22);
        	this.ItemPhpPhat.Text = "Ubicación";
        	// 
        	// ItemPHPINI
        	// 
        	this.ItemPHPINI.Name = "ItemPHPINI";
        	this.ItemPHPINI.Size = new System.Drawing.Size(176, 22);
        	this.ItemPHPINI.Text = "Configuración (INI)";
        	// 
        	// ItemConVisualPHP
        	// 
        	this.ItemConVisualPHP.Name = "ItemConVisualPHP";
        	this.ItemConVisualPHP.Size = new System.Drawing.Size(176, 22);
        	this.ItemConVisualPHP.Text = "Configurar";
        	// 
        	// listView1
        	// 
        	this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
			| System.Windows.Forms.AnchorStyles.Left) 
			| System.Windows.Forms.AnchorStyles.Right)));
        	this.listView1.BackgroundImageTiled = true;
        	this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
			this.columnHeader1,
			this.columnHeader2,
			this.columnHeader3,
			this.columnHeader4});
        	this.listView1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.listView1.FullRowSelect = true;
        	this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
			listViewItem1,
			listViewItem2,
			listViewItem3,
			listViewItem4,
			listViewItem5,
			listViewItem6,
			listViewItem7,
			listViewItem8});
        	this.listView1.LargeImageList = this.imageList1;
        	this.listView1.Location = new System.Drawing.Point(153, 97);
        	this.listView1.Name = "listView1";
        	this.listView1.Size = new System.Drawing.Size(508, 420);
        	this.listView1.SmallImageList = this.imageList1;
        	this.listView1.TabIndex = 11;
        	this.listView1.UseCompatibleStateImageBehavior = false;
        	this.listView1.View = System.Windows.Forms.View.Details;
        	// 
        	// columnHeader1
        	// 
        	this.columnHeader1.Text = "Nombre";
        	this.columnHeader1.Width = 177;
        	// 
        	// columnHeader2
        	// 
        	this.columnHeader2.Text = "PID";
        	this.columnHeader2.Width = 106;
        	// 
        	// columnHeader3
        	// 
        	this.columnHeader3.Text = "Puerto";
        	this.columnHeader3.Width = 97;
        	// 
        	// columnHeader4
        	// 
        	this.columnHeader4.Text = "Proceso";
        	this.columnHeader4.Width = 112;
        	// 
        	// button3
        	// 
        	this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        	this.button3.Image = global::Hox.Properties.Resources.phpPgAdmin;
        	this.button3.Location = new System.Drawing.Point(598, 46);
        	this.button3.Name = "button3";
        	this.button3.Size = new System.Drawing.Size(63, 45);
        	this.button3.TabIndex = 29;
        	this.button3.UseVisualStyleBackColor = true;
        	// 
        	// pictureBox1
        	// 
        	this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
        	this.pictureBox1.Location = new System.Drawing.Point(4, 23);
        	this.pictureBox1.Name = "pictureBox1";
        	this.pictureBox1.Size = new System.Drawing.Size(211, 68);
        	this.pictureBox1.TabIndex = 28;
        	this.pictureBox1.TabStop = false;
        	// 
        	// BtnTomc
        	// 
        	this.BtnTomc.FlatAppearance.BorderSize = 0;
        	this.BtnTomc.Image = global::Hox.Properties.Resources.Player_stop;
        	this.BtnTomc.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
        	this.BtnTomc.Location = new System.Drawing.Point(4, 151);
        	this.BtnTomc.Name = "BtnTomc";
        	this.BtnTomc.Size = new System.Drawing.Size(92, 50);
        	this.BtnTomc.TabIndex = 8;
        	this.BtnTomc.Text = "Tomcat";
        	this.BtnTomc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        	this.BtnTomc.UseVisualStyleBackColor = true;
        	// 
        	// BtbMon
        	// 
        	this.BtbMon.FlatAppearance.BorderSize = 0;
        	this.BtbMon.Image = global::Hox.Properties.Resources.Player_stop;
        	this.BtbMon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
        	this.BtbMon.Location = new System.Drawing.Point(4, 260);
        	this.BtbMon.Name = "BtbMon";
        	this.BtbMon.Size = new System.Drawing.Size(92, 50);
        	this.BtbMon.TabIndex = 27;
        	this.BtbMon.Text = "Mongo";
        	this.BtbMon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        	this.BtbMon.UseVisualStyleBackColor = true;
        	// 
        	// button1
        	// 
        	this.button1.FlatAppearance.BorderSize = 0;
        	this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        	this.button1.Image = global::Hox.Properties.Resources.mongo;
        	this.button1.Location = new System.Drawing.Point(102, 264);
        	this.button1.Name = "button1";
        	this.button1.Size = new System.Drawing.Size(45, 50);
        	this.button1.TabIndex = 26;
        	this.button1.UseVisualStyleBackColor = true;
        	// 
        	// button2
        	// 
        	this.button2.FlatAppearance.BorderSize = 0;
        	this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        	this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
        	this.button2.Location = new System.Drawing.Point(102, 319);
        	this.button2.Name = "button2";
        	this.button2.Size = new System.Drawing.Size(45, 50);
        	this.button2.TabIndex = 25;
        	this.button2.UseVisualStyleBackColor = true;
        	// 
        	// BtnPostGre
        	// 
        	this.BtnPostGre.FlatAppearance.BorderSize = 0;
        	this.BtnPostGre.Image = global::Hox.Properties.Resources.Player_stop;
        	this.BtnPostGre.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
        	this.BtnPostGre.Location = new System.Drawing.Point(4, 316);
        	this.BtnPostGre.Name = "BtnPostGre";
        	this.BtnPostGre.Size = new System.Drawing.Size(92, 50);
        	this.BtnPostGre.TabIndex = 24;
        	this.BtnPostGre.Text = "PostGre";
        	this.BtnPostGre.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        	this.BtnPostGre.UseVisualStyleBackColor = true;
        	// 
        	// PHPbtn
        	// 
        	this.PHPbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        	this.PHPbtn.Image = global::Hox.Properties.Resources._170px_PHP_logod;
        	this.PHPbtn.Location = new System.Drawing.Point(461, 45);
        	this.PHPbtn.Name = "PHPbtn";
        	this.PHPbtn.Size = new System.Drawing.Size(63, 45);
        	this.PHPbtn.TabIndex = 23;
        	this.PHPbtn.UseVisualStyleBackColor = true;
        	// 
        	// BtnExplorador
        	// 
        	this.BtnExplorador.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        	this.BtnExplorador.Image = global::Hox.Properties.Resources.application;
        	this.BtnExplorador.Location = new System.Drawing.Point(392, 46);
        	this.BtnExplorador.Name = "BtnExplorador";
        	this.BtnExplorador.Size = new System.Drawing.Size(63, 45);
        	this.BtnExplorador.TabIndex = 22;
        	this.BtnExplorador.UseVisualStyleBackColor = true;
        	// 
        	// PhMyAminbnt
        	// 
        	this.PhMyAminbnt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        	this.PhMyAminbnt.Image = ((System.Drawing.Image)(resources.GetObject("PhMyAminbnt.Image")));
        	this.PhMyAminbnt.Location = new System.Drawing.Point(530, 46);
        	this.PhMyAminbnt.Name = "PhMyAminbnt";
        	this.PhMyAminbnt.Size = new System.Drawing.Size(63, 45);
        	this.PhMyAminbnt.TabIndex = 21;
        	this.PhMyAminbnt.UseVisualStyleBackColor = true;
        	// 
        	// button8
        	// 
        	this.button8.FlatAppearance.BorderSize = 0;
        	this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        	this.button8.Image = global::Hox.Properties.Resources._50px_Mysql;
        	this.button8.Location = new System.Drawing.Point(102, 210);
        	this.button8.Name = "button8";
        	this.button8.Size = new System.Drawing.Size(45, 50);
        	this.button8.TabIndex = 14;
        	this.button8.UseVisualStyleBackColor = true;
        	// 
        	// button7
        	// 
        	this.button7.FlatAppearance.BorderSize = 0;
        	this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        	this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
        	this.button7.Location = new System.Drawing.Point(102, 100);
        	this.button7.Name = "button7";
        	this.button7.Size = new System.Drawing.Size(45, 45);
        	this.button7.TabIndex = 13;
        	this.button7.UseVisualStyleBackColor = true;
        	// 
        	// button12
        	// 
        	this.button12.FlatAppearance.BorderSize = 0;
        	this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        	this.button12.Image = global::Hox.Properties.Resources.argo;
        	this.button12.Location = new System.Drawing.Point(102, 487);
        	this.button12.Name = "button12";
        	this.button12.Size = new System.Drawing.Size(45, 50);
        	this.button12.TabIndex = 18;
        	this.button12.UseVisualStyleBackColor = true;
        	// 
        	// button11
        	// 
        	this.button11.FlatAppearance.BorderSize = 0;
        	this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        	this.button11.Image = global::Hox.Properties.Resources.tomcat;
        	this.button11.Location = new System.Drawing.Point(102, 155);
        	this.button11.Name = "button11";
        	this.button11.Size = new System.Drawing.Size(45, 45);
        	this.button11.TabIndex = 17;
        	this.button11.UseVisualStyleBackColor = true;
        	// 
        	// button10
        	// 
        	this.button10.FlatAppearance.BorderSize = 0;
        	this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        	this.button10.Image = global::Hox.Properties.Resources.g;
        	this.button10.Location = new System.Drawing.Point(102, 431);
        	this.button10.Name = "button10";
        	this.button10.Size = new System.Drawing.Size(45, 50);
        	this.button10.TabIndex = 16;
        	this.button10.UseVisualStyleBackColor = true;
        	// 
        	// button9
        	// 
        	this.button9.FlatAppearance.BorderSize = 0;
        	this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        	this.button9.Image = global::Hox.Properties.Resources.fff;
        	this.button9.Location = new System.Drawing.Point(102, 375);
        	this.button9.Name = "button9";
        	this.button9.Size = new System.Drawing.Size(45, 50);
        	this.button9.TabIndex = 15;
        	this.button9.UseVisualStyleBackColor = true;
        	// 
        	// BtbMysql
        	// 
        	this.BtbMysql.FlatAppearance.BorderColor = System.Drawing.Color.Black;
        	this.BtbMysql.FlatAppearance.BorderSize = 0;
        	this.BtbMysql.Image = global::Hox.Properties.Resources.Player_stop;
        	this.BtbMysql.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
        	this.BtbMysql.Location = new System.Drawing.Point(4, 207);
        	this.BtbMysql.Name = "BtbMysql";
        	this.BtbMysql.Size = new System.Drawing.Size(92, 50);
        	this.BtbMysql.TabIndex = 1;
        	this.BtbMysql.Text = "Mysql";
        	this.BtbMysql.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        	this.BtbMysql.UseVisualStyleBackColor = true;
        	// 
        	// BtnApache
        	// 
        	this.BtnApache.FlatAppearance.BorderSize = 0;
        	this.BtnApache.Image = global::Hox.Properties.Resources.Player_stop;
        	this.BtnApache.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
        	this.BtnApache.Location = new System.Drawing.Point(4, 95);
        	this.BtnApache.Name = "BtnApache";
        	this.BtnApache.Size = new System.Drawing.Size(92, 50);
        	this.BtnApache.TabIndex = 0;
        	this.BtnApache.Text = "Apache";
        	this.BtnApache.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        	this.BtnApache.UseVisualStyleBackColor = true;
        	// 
        	// BtbArg
        	// 
        	this.BtbArg.FlatAppearance.BorderSize = 0;
        	this.BtbArg.Image = global::Hox.Properties.Resources.Player_stop;
        	this.BtbArg.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
        	this.BtbArg.Location = new System.Drawing.Point(4, 484);
        	this.BtbArg.Name = "BtbArg";
        	this.BtbArg.Size = new System.Drawing.Size(92, 50);
        	this.BtbArg.TabIndex = 9;
        	this.BtbArg.Text = "ArgoSoft";
        	this.BtbArg.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        	this.BtbArg.UseVisualStyleBackColor = true;
        	// 
        	// BtnMer
        	// 
        	this.BtnMer.FlatAppearance.BorderSize = 0;
        	this.BtnMer.Image = global::Hox.Properties.Resources.Player_stop;
        	this.BtnMer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
        	this.BtnMer.Location = new System.Drawing.Point(4, 428);
        	this.BtnMer.Name = "BtnMer";
        	this.BtnMer.Size = new System.Drawing.Size(92, 50);
        	this.BtnMer.TabIndex = 3;
        	this.BtnMer.Text = "Mercury";
        	this.BtnMer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        	this.BtnMer.UseVisualStyleBackColor = true;
        	// 
        	// BtnFil
        	// 
        	this.BtnFil.FlatAppearance.BorderSize = 0;
        	this.BtnFil.Image = global::Hox.Properties.Resources.Player_stop;
        	this.BtnFil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
        	this.BtnFil.Location = new System.Drawing.Point(4, 372);
        	this.BtnFil.Name = "BtnFil";
        	this.BtnFil.Size = new System.Drawing.Size(92, 50);
        	this.BtnFil.TabIndex = 2;
        	this.BtnFil.Text = "FileZilla";
        	this.BtnFil.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
        	this.BtnFil.UseVisualStyleBackColor = true;
        	// 
        	// versionDePHPToolStripMenuItem
        	// 
        	this.versionDePHPToolStripMenuItem.Name = "versionDePHPToolStripMenuItem";
        	this.versionDePHPToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
        	this.versionDePHPToolStripMenuItem.Text = "Versiòn de PHP";
        	// 
        	// FmrHox
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.ClientSize = new System.Drawing.Size(671, 570);
        	this.Controls.Add(this.button3);
        	this.Controls.Add(this.pictureBox1);
        	this.Controls.Add(this.BtnTomc);
        	this.Controls.Add(this.BtbMon);
        	this.Controls.Add(this.button1);
        	this.Controls.Add(this.button2);
        	this.Controls.Add(this.BtnPostGre);
        	this.Controls.Add(this.PHPbtn);
        	this.Controls.Add(this.BtnExplorador);
        	this.Controls.Add(this.PhMyAminbnt);
        	this.Controls.Add(this.button8);
        	this.Controls.Add(this.button7);
        	this.Controls.Add(this.button12);
        	this.Controls.Add(this.button11);
        	this.Controls.Add(this.button10);
        	this.Controls.Add(this.button9);
        	this.Controls.Add(this.menuStrip1);
        	this.Controls.Add(this.listView1);
        	this.Controls.Add(this.statusStrip1);
        	this.Controls.Add(this.BtbMysql);
        	this.Controls.Add(this.BtnApache);
        	this.Controls.Add(this.BtbArg);
        	this.Controls.Add(this.BtnMer);
        	this.Controls.Add(this.BtnFil);
        	this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
        	this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        	this.Name = "FmrHox";
        	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        	this.Text = "Hox ";
        	this.Load += new System.EventHandler(this.FmrHox_Load_1);
        	this.menuStrip1.ResumeLayout(false);
        	this.menuStrip1.PerformLayout();
        	this.OpcionNavegacion.ResumeLayout(false);
        	this.OpcionPHP.ResumeLayout(false);
        	((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
        	this.ResumeLayout(false);
        	this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnApache;
        private System.Windows.Forms.Button BtbMysql;
        private System.Windows.Forms.Button BtnFil;
        private System.Windows.Forms.Button BtnMer;
        private System.Windows.Forms.Button BtnTomc;
        private System.Windows.Forms.Button BtbArg;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem apcheToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pHPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pHPMYADMINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HostAlterToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem editoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pHPToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mySQLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.ToolStripMenuItem mercuryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tomcatToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sobreEsteProgramaToolStripMenuItem;
        private System.Windows.Forms.Button PhMyAminbnt;
        private System.Windows.Forms.Button BtnExplorador;
        private System.Windows.Forms.ToolStripMenuItem fileZillaServerInterfaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileZillaServerXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mySQLINIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem apacheconfToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem phatToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem phatToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem MerStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem MerINIStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem ubiMerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TomserverXMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TomubicaciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pHPToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem pHPINIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PHPubicaciónToolStripMenuItem1;
        private System.Windows.Forms.Button PHPbtn;
        private System.Windows.Forms.ContextMenuStrip OpcionNavegacion;
        private System.Windows.Forms.ToolStripMenuItem ApacheWeb;
        private System.Windows.Forms.ToolStripMenuItem TomcatWeb;
        private System.Windows.Forms.ToolStripMenuItem ArgoSoftWeb;
        private System.Windows.Forms.Button BtnPostGre;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem postGreSQLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem INIPostgre;
        private System.Windows.Forms.ToolStripMenuItem UbiPostgre;
        private System.Windows.Forms.ContextMenuStrip OpcionPHP;
        private System.Windows.Forms.ToolStripMenuItem ItemPhpPhat;
        private System.Windows.Forms.ToolStripMenuItem ItemPHPINI;
        private System.Windows.Forms.ToolStripMenuItem ItemConVisualPHP;
        private System.Windows.Forms.ToolStripMenuItem httpwwwworlcomcomToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button BtbMon;
        private System.Windows.Forms.ToolStripMenuItem mongoDBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rutaDeDBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ubicacionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RutaMogo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripMenuItem versionDePHPToolStripMenuItem;
    }
}

