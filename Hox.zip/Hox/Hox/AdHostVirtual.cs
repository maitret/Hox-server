﻿//Entorno de desarrollo para aplicaciones web Alternativa a Xampp, Wamp Appserv y demás, 
// Copyright (C ) Rodrigo Chambi Q, Email infohoxserver@asqki.com http://www.hoxserver.asqki.com
//
// Este programa es software libre; usted puede redistribuirlo y / o
// Modificarlo bajo los términos de la Licencia Pública General de GNU
// Publicada por la Free Software Foundation; ya sea la versión 2
// De la Licencia, o (a su elección) cualquier versión posterior .
//
// Este programa se distribuye con la esperanza de que sea útil,
// Pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de
// COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. ver el

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Hox
{
    public partial class AdHostVirtual : Form
    {
        public AdHostVirtual()
        {
            InitializeComponent();
            BtnCancel.DialogResult = DialogResult.Cancel;
            BtnAceptar.DialogResult = DialogResult.OK;
            BtnAceptar.Click += BtnAceptar_Click;
            btnSubDom.Click += btnSubDom_Click;
            BtnDom.Click += BtnDom_Click; 
          
        }

        void BtnDom_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog Directorio = new FolderBrowserDialog();
            if (Directorio.ShowDialog() == DialogResult.OK){
                Regex Veficar = new Regex(@"\s");
                if (Veficar.IsMatch(Directorio.SelectedPath) == true){
                    MessageBox.Show("La carpeta que seleccionaste  tiene un nombre con espacios vacios \n  se requiere una carpeta sin espacios vacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    comboBox2.Text = "";
                }
                else {
                    RutaDom_ = Directorio.SelectedPath.Replace((char)calor, '/');
                    comboBox2.Text = RutaDom_;
                } 
               
            }
        }
       
        void btnSubDom_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog Directorio = new FolderBrowserDialog();
            if (Directorio.ShowDialog() == DialogResult.OK)
            {
                Regex Veficar = new Regex(@"\s");
                if (Veficar.IsMatch(Directorio.SelectedPath) == true){
                    MessageBox.Show("La carpeta que seleccionaste  tiene un nombre con espacios vacios \n  se requiere una carpeta sin espacios vacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    comboBox1.Text = "";
                }
                else{
                    RutasubDom_ = Directorio.SelectedPath.Replace((char)calor, '/');
                    comboBox1.Text = RutasubDom_;
                 
                }

               
            }
        }

        void BtnAceptar_Click(object sender, EventArgs e) {
            SubDom_ = textBox1.Text;
            Dominio_ = textBox2.Text; 
            RutaDom_=comboBox2.Text;
            RutasubDom_=comboBox1.Text;
        }
        private const int calor = 92;
        private string RutasubDom_;
        private string SubDom_;
        private string RutaDom_;
        private string Dominio_;
        /// <summary>
        /// Obtiene y establece el directorio
        /// del sub dominio
        /// </summary>
        public string RutaSubDominio { get { return RutasubDom_; } set { RutasubDom_ = value; } }
        /// <summary>
        /// Obtiene y establece subdomio
        /// </summary>
        public string SubDominio { get { return SubDom_; } set { SubDom_ = value; } }
        /// <summary>
        /// Otiene y establece  el directorio
        /// del Dominio principal
        /// </summary>
        public string RutaDominio { get { return RutaDom_; } set { RutaDom_ = value; } }
        /// <summary>
        /// Otiene y establece el dominio de internet local
        /// </summary>
        public string Dominio { get { return Dominio_; } set { Dominio_ = value; } }
		void GroupBox2Enter(object sender, EventArgs e)
		{
	
		}
		void AdHostVirtualLoad(object sender, EventArgs e){
			if(RutaDom_!="" && Dominio_!=""){
				textBox2.Text=Dominio_;
				comboBox2.Text=RutaDom_;
			}
		}


    }
}
