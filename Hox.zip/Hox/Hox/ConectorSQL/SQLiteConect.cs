﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;   
namespace Hox.ConectorSQL
{
    public partial class SQLiteConect : Form{
        public SQLiteConect(){
            InitializeComponent();
            btnConect.Click += btnConect_Click;
            BtnRuta.Click += BtnRuta_Click;
            txtRuta.DoubleClick += txtRuta_DoubleClick;
            btnAcept.DialogResult =DialogResult.OK ;
            btnCancel.DialogResult = DialogResult.Cancel;
        }
        //campos
        private SaveFileDialog guardar = new SaveFileDialog();
        private OpenFileDialog Abrir = new OpenFileDialog();
        private string rutaArchivo = string.Empty;
        private string NombreConect = string.Empty;
        private string NombreDB_ = string.Empty;  
        private bool isconection_;
        /// <summary>
        /// Otiene y establece el nombre
        /// de la base datos
        /// </summary>
        public string NombreDB {
            get { return NombreDB_; }
            set { NombreDB_ = value; }
        }
        /// <summary>
        /// Otien y estable nombre de conexion
        /// </summary>
        public string NombreCenect {
            get { return NombreConect; }
            set { NombreConect = value; }
        }
        /// <summary>
        /// Obtiene la ruta del archivo SQLITE
        /// </summary>
        public string RutaConect {
            get { return rutaArchivo; }
        }
        public bool Isconection {
            get { return isconection_; }
        }
        private void metodod() {
            if (rtbutonnew.Checked == true)
            {
                
                guardar.Filter = "Archivo SQLite |*.db;*.db3;*.sqlite*.sqlite3;|Todo los achivos|*.*";
                if (guardar.ShowDialog() == DialogResult.OK) {
                    SQLiteConnection.CreateFile(guardar.FileName);
                    rutaArchivo = guardar.FileName;
                    txtRuta.Text = guardar.FileName;
                }
            }
            else
            {
                Abrir.CheckFileExists = true;
                Abrir.Filter = "Archivo SQLite |*.db;*.db3;*.sqlite*.sqlite3;|Todo los achivos|*.*";
                if (Abrir.ShowDialog() == DialogResult.OK)
                {
                    txtRuta.Text = Abrir.FileName;
                    rutaArchivo = Abrir.FileName;
                }
            }
        }
        void txtRuta_DoubleClick(object sender, EventArgs e){
            metodod();
        }
        /// <summary>
        /// Otiene la ruta del archivo Sql
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void BtnRuta_Click(object sender, EventArgs e)
        {
            metodod();
        }

        void btnConect_Click(object sender, EventArgs e)
        {
            if (File.Exists(rutaArchivo) == true) {
                try {
                    SQLiteConnection conect = new SQLiteConnection("Data Source=" + rutaArchivo + ";Version=3;");
                    conect.Open();
                    SQLiteCommand comando = new SQLiteCommand("SELECT * FROM sqlite_master;", conect);
                    comando.ExecuteReader();
                    this.pictureBox1.Image = global::Hox.Properties.Resources.connect;
                    LabeError.Text = "Conexiòn exitosa";
                    MessageBox.Show("Conexión correcta", "Conexión", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    conect.Close();
                    isconection_ = true;
                    NombreConect = txtNobreconect.Text;
                    FileInfo nombre = new FileInfo(rutaArchivo);
                    NombreDB = nombre.Name.Substring(0, nombre.Name.Length - 4);   
                }
                catch (SQLiteException  exe) {
                    this.pictureBox1.Image = global::Hox.Properties.Resources.desconect;
                    LabeError.Text = "Error no se puede conectar con el archivo";
                    isconection_ = false;
                }
               

            }
        }
    }
}
