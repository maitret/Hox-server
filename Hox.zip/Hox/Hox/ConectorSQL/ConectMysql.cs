﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;   
namespace Hox.ConectorSQL
{
    public partial class ConectMysql : Form
    {
        public ConectMysql()
        {
            InitializeComponent();
            btnConect.Click += btnConect_Click;
            this.pictureBox1.Visible = false;
            btnAcept.DialogResult = DialogResult.OK;
            btnCancel.DialogResult = DialogResult.Cancel;   
        }
        /// <summary>
        /// Campos
        /// </summary>
        String ConexionIndex = string.Empty;
        private string NombreConect = string.Empty;
        private bool isconection_;
      
        /// <summary>
        /// Otien y estable nombre de conexion
        /// </summary>
        public string NombreCenect
        {
            get { return NombreConect; }
            set { NombreConect = value; }
        }
        /// <summary>
        /// Obtiene y establece 
        /// la cadena  de conexion
        /// al servidor MYSQL
        /// </summary>
        public string Conection
        {
            get { return ConexionIndex ; }
            set { ConexionIndex = value; }
        }
        /// <summary>
        /// Obtien el valor true si es que ha conectado
        /// al servidor por cotrario un false
        /// </summary>
        public bool Isconection
        {
            get { return isconection_; }
        }
            /// <summary>
        /// comprueba la conexion conexion a mysql
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnConect_Click(object sender, EventArgs e)
        {
            this.pictureBox1.Visible = true;    
            try{
                ConexionIndex = "Server=" + textBox2.Text + ";Port=" + textBox3.Text + ";Database=" + textBox4.Text + ";Uid=" + textBox5.Text + ";Pwd=" + textBox6.Text + ";";
 
                MySqlConnection conexion = new MySqlConnection(ConexionIndex);
                conexion.Open();
                this.pictureBox1.Image = global::Hox.Properties.Resources.connect ;
                LabeError.Text = "Conexiòn exitosa"; 
                MessageBox.Show("Conexión correcta", "Conexión", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conexion.Close();
                isconection_ = true;
                NombreConect = TxtNombreConect.Text ;
            }
            catch (MySqlException ss){
                this.pictureBox1.Image = global::Hox.Properties.Resources.desconect;
               LabeError.Text ="Error no se puede conectar con el servidor Mysql";
               isconection_ = false; 
              
            }
        }
    }
}
