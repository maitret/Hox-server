﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SQLite;
using System.Data.SqlClient;
using MongoDB.Connections;
using MySql.Data.MySqlClient;
using System.Collections;   
namespace Hox.ConectorSQL{
    public enum TipoDB{ 
        SQLite,
        MySQL,
        PostGreSQL,
        MongoDB
    }
    class InformSQL {
        /// <summary>
        /// Inicia la cadena de conexion
        /// </summary>
        /// <param name="Conetion"></param>
        public InformSQL(String Conetion){
            CadenaConecxion_ = Conetion;//Establece la cadena de coneccion
            ListaTable.Clear();//Borra la lista  
        }
        /// <summary>
        /// Campos
        /// </summary>
        private String CadenaConecxion_;
        private  SQLiteConnection Conectar;
        private ArrayList ListaTable = new ArrayList();
        /// <summary>
        /// Determina la existencia de la Tabla
        /// </summary>
        /// <param name="Query">Consulta SQL</param>
        /// <param name="TypeDB">Tipo de gestor de base de datos</param>
        /// <returns>bool</returns>
        public bool IsExistTable(TipoDB TypeDB) {
            bool returnexist = false;
            switch (TypeDB){ 
                case TipoDB.SQLite:
                    Conectar = new SQLiteConnection(CadenaConecxion_);
                    Conectar.Open();
                    using (SQLiteCommand Comando = new SQLiteCommand("SELECT name FROM sqlite_master WHERE type = 'table' AND name<>'sqlite_stat1'", Conectar)) { 
                    SQLiteDataReader sqlDataReader = Comando.ExecuteReader();
                            if (sqlDataReader.Read()){
                                returnexist= true;
                                ListarTablas(TypeDB);
                            }else{
                                returnexist= false;
                                }
                        Conectar.Close();
                    }
                    break; 
                case  TipoDB.MySQL:
                    break;
                case TipoDB.PostGreSQL:
                    break;
                case TipoDB.MongoDB:
                    break; 
            }
            return returnexist;//Retorna la existencia de las tablas 
        }
        /// <summary>
        /// Carga  una coleccion de tablas
        /// </summary>
        /// <param name="TypeDB"></param>
        private void ListarTablas(TipoDB TypeDB){
            switch (TypeDB) { 
                case TipoDB.SQLite:
                    Conectar = new SQLiteConnection(CadenaConecxion_);
                    Conectar.Open();
                    using (SQLiteCommand Comando = new SQLiteCommand("SELECT name FROM sqlite_master WHERE type = 'table' AND name<>'sqlite_stat1'", Conectar)){
                        SQLiteDataReader sqlDataReader = Comando.ExecuteReader();
                        while (sqlDataReader.Read()){
                            ListaTable.Add(sqlDataReader[0].ToString()); 
                        }
                    }
                    break;
                case TipoDB.MySQL:
                    break;
                case TipoDB.PostGreSQL:
                    break;
                case TipoDB.MongoDB:
                    break; 
            }
        }
        /// <summary>
        /// Obtiene y estable
        /// un lista  de tablas
        /// de tipo ArrayList
        /// </summary>
        public ArrayList Tablas {
            get { return ListaTable; }
            set { ListaTable = value; } 
        }



    }
}
