﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Hox.ConectorSQL
{
    public partial class InitFormSQL : Form
    {
        public InitFormSQL()
        {
            InitializeComponent();
            mySQLToolStripMenuItem.Click += mySQLToolStripMenuItem_Click;
            mySQLToolStripMenuItem1.Click += mySQLToolStripMenuItem_Click;
            sQLiteToolStripMenuItem.Click += sQLiteToolStripMenuItem_Click;
            sQLiteToolStripMenuItem1.Click += sQLiteToolStripMenuItem_Click;
        }
        private int IncrementNameconect;
        private int IcrementMysqlConectName;
        void sQLiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SQLiteConect conectar = new SQLiteConect();
            if (conectar.ShowDialog() == DialogResult.OK) {
                if (conectar.Isconection == true)
                {
                    if (conectar.NombreCenect != "") { }
                    else
                    {
                        IncrementNameconect++;
                        conectar.NombreCenect = "Nueva Conexiòn SQLite" + IncrementNameconect;
                    }
                    if (conectar.NombreDB != "") { }
                    else
                    {
                        FileInfo nombre = new FileInfo(conectar.RutaConect);
                        conectar.NombreDB = nombre.Name.Substring(0, nombre.Name.Length - 4);
                    }
                    //    MessageBox.Show(conectar.RutaConect +"----" + conectar.NombreCenect   );
                    //    TreeNode treeNode1 = new TreeNode("Nodo2");
                    TreeNode treeNode2 = new TreeNode(conectar.NombreDB /*new System.Windows.Forms.TreeNode[] {treeNode1}*/);
                    treeNode2.ImageIndex = 4;
                    treeNode2.SelectedImageIndex = 4;
                    InformSQL nuevoInforme = new InformSQL("Data Source=" + conectar.RutaConect + ";Version=3;");
                    if(nuevoInforme.IsExistTable(TipoDB.SQLite)){
                        foreach (string tablas in nuevoInforme.Tablas ){
                            TreeNode Nodo = new TreeNode();
                            Nodo.Text = tablas; 
                            Nodo.ImageIndex = 5;
                            Nodo.SelectedImageIndex = 5;
                            treeNode2.Nodes.Add(Nodo);
                        }
                    }
                    
                    TreeNode treeNode1 = new TreeNode(conectar.NombreCenect, new System.Windows.Forms.TreeNode[] { treeNode2 });
                    treeNode1.Tag = conectar.RutaConect;
                    treeNode1.ImageIndex = 1;
                    treeNode1.SelectedImageIndex = 1;
                    treeNode1.Expand();
                    NodosDB.Nodes.Add(treeNode1);
                    conectar.Dispose();
                }
                else
                {

                    MessageBox.Show("No se ha podido establecer la conexiòn intente de nuevo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information); 
      
                }
                
            }   
        }
        /// <summary>
        /// inicia el cuadro de dialogo a conexion Mysql
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void mySQLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConectMysql Nuevo = new ConectMysql();

            if (Nuevo.ShowDialog() == DialogResult.OK)
            {
                if (Nuevo.Isconection == true)
                {
                    if (Nuevo.NombreCenect != "") { }
                    else
                    {
                        IcrementMysqlConectName++;
                        Nuevo.NombreCenect = "Nueva conexiòn a MYSQL" + IcrementMysqlConectName.ToString();
                    }

                }
                else {
                    MessageBox.Show("No se ha podido establecer la conexiòn intente de nuevo","Error",MessageBoxButtons.OK ,MessageBoxIcon.Information   ); 
                }
               
            }   
        }
    }
}
