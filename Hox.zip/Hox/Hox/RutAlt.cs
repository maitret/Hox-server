﻿//Entorno de desarrollo para aplicaciones web Alternativa a Xampp, Wamp Appserv y demás, 
// Copyright (C ) Rodrigo Chambi Q, Email infohoxserver@asqki.com http://www.hoxserver.asqki.com
//
// Este programa es software libre; usted puede redistribuirlo y / o
// Modificarlo bajo los términos de la Licencia Pública General de GNU
// Publicada por la Free Software Foundation; ya sea la versión 2
// De la Licencia, o (a su elección) cualquier versión posterior .
//
// Este programa se distribuye con la esperanza de que sea útil,
// Pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de
// COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. ver el

using System;
using System.Linq;
using System.Text.RegularExpressions ;
using System.Text; 
using System.Windows.Forms;
using System.IO;
using Microsoft.VisualBasic.Devices;
using System.Collections;  
namespace Hox
{
    public partial class RutAlt : Form
    {
        public RutAlt(){
            InitializeComponent();
            this.Load += RutAlt_Load;
            BtbAgregar.Click += BtbAgregar_Click;
            BtnDelete.Click += BtnDelete_Click;
            eliminarToolStripMenuItem.Click += eliminarToolStripMenuItem_Click;
            agregarToolStripMenuItem.Click += agregarToolStripMenuItem_Click;
            Modificar.Click +=ModicarHostVirtual;
            BtnCancel.Click +=Cancelar;
        }
    	private const int calor = 92;
    	
    	
    	void Cancelar(object sender, EventArgs e){
    		this.Close();
    	}
    	/// <summary>
    	/// Boton modificar el host virtual
    	/// </summary>
    	/// <param name="sender"></param>
    	/// <param name="e"></param>
    	void ModicarHostVirtual(object sender, EventArgs e){
    		AdHostVirtual Modificar=new AdHostVirtual();
    		if(ListHostVistuales.Items.Count>0){
    		Modificar.Dominio=ListHostVistuales.SelectedItems[0].Text;
    		String RutaDominio=ListHostVistuales.SelectedItems[0].SubItems[1].Text.Replace((char)calor, '\\');
    		Modificar.RutaDominio=RutaDominio;
            if(Modificar.ShowDialog()==DialogResult.OK){
            	ListHostVistuales.SelectedItems[0].Text=Modificar.Dominio;
            	ListHostVistuales.SelectedItems[0].SubItems[1].Text=Modificar.RutaDominio;
            	GuardarConfiguracion();
                leer();
            }
    		}

    	}
    	
        void agregarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AgregarNuevoHost();
        }

        void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EliminarHostlocal();
        }
        /// <summary>
        /// Elimina la lista de dominios locales
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void BtnDelete_Click(object sender, EventArgs e){
            EliminarHostlocal();
        }
        /// <summary>
        /// Elimana la lista selecionado de 
        /// dominios locales creados
        /// </summary>
        private void EliminarHostlocal() {
            if (ListHostVistuales.SelectedItems.Count > 0) {
                foreach (ListViewItem items in ListHostVistuales.SelectedItems){
                    if (items.Text == "localhost") { }
                    else{
                        items.Remove();
                    }

                }
            }
            GuardarConfiguracion();
            leer();
        }

        void RutAlt_Load(object sender, EventArgs e)
        {
            leer();
        }

        private ArrayList ListaRuta = new ArrayList();
        private ArrayList ListaDominio = new ArrayList();
        private StringBuilder Escribir_Configuracion_=new  StringBuilder ();
        private StringBuilder Escribir_Host_Configu_ = new StringBuilder();
        private void ObtenDirecotrios() {
            try { 
            foreach (ListViewItem items in ListHostVistuales.Items){
                if (ListaRuta.Contains(items.SubItems[1].Text)){ }
                else{
                    ListaRuta.Add(items.SubItems[1].Text);
                }
                if (items.SubItems[2].Text == "Dominio") { 
                if (ListaDominio.Contains(items.SubItems[0].Text)) { } else {
                    ListaDominio.Add(items.SubItems[0].Text);
                }
                }
            }
                }catch {
                }
        }
       /// <summary>
       /// Guarda nueva configuracion 
       /// a los archivos de configruacion
        /// apache y C:\Windows\System32\Drivers\etc\host
       /// </summary>
        private void GuardarConfiguracion(){
            ListaRuta.Clear();
            Escribir_Configuracion_.Clear();
            Escribir_Host_Configu_.Clear();
            ObtenDirecotrios();
            foreach (string dirs in ListaRuta){
                Escribir_Configuracion_.AppendLine("#Se establece permisos para la ruta " + dirs);
                Escribir_Configuracion_.AppendLine("<Directory \"" + dirs + "\">");
                Escribir_Configuracion_.AppendLine("AllowOverride All");
                Escribir_Configuracion_.AppendLine("Require all granted");
                Escribir_Configuracion_.AppendLine("</Directory>");
            }

            foreach (ListViewItem items in ListHostVistuales.Items){
                if (items.SubItems[2].Text == "Dominio"){
                    Escribir_Configuracion_.AppendLine("#Dominio local " + items.SubItems[0].Text);
                    Escribir_Configuracion_.AppendLine("<VirtualHost *:80>");
                    Escribir_Configuracion_.AppendLine("DocumentRoot \"" + items.SubItems[1].Text + "\"");
                    Escribir_Configuracion_.AppendLine("ServerName " + items.SubItems[0].Text);
                    Escribir_Configuracion_.AppendLine("</VirtualHost>");
                }
                else{
                    Escribir_Configuracion_.AppendLine("#Sub Dominio local " + items.SubItems[0].Text);
                    Escribir_Configuracion_.AppendLine("Alias " + items.SubItems[0].Text + "  \"" + items.SubItems[1].Text + "\"");
                }
                
            }
            //almacena para  escribir en la ruta WINDOWS\system32\drivers\etc\hosts
            foreach (string dominio in ListaDominio)
            {
                Escribir_Host_Configu_.AppendLine("127.0.0.1 " + dominio);
            }
            //Metodos que guardan al archivo de configuracion
            Escribir();//Apache
            EscribirDriver();//Dominios locales windows
        }

        /// <summary>
        /// Agrega una nueva extesion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void BtbAgregar_Click(object sender, EventArgs e){
            AgregarNuevoHost();
        }
        /// <summary>
        /// Agregra un nuevo 
        /// dominio local
        /// </summary>
        private void AgregarNuevoHost() {
            AdHostVirtual Nuevo = new AdHostVirtual();
            if (Nuevo.ShowDialog() == DialogResult.OK)
            {
                if (Nuevo.RutaDominio == "") { }
                else {
                    if (Nuevo.Dominio == "") { }
                    else {
                        if (Directory.Exists(Nuevo.RutaDominio))
                        {
                            Regex Dominio = new Regex(@"\b(www)+\.[a-zA-Z\d]+\.[a-zA-Z]\b");
                            if (Dominio.IsMatch(Nuevo.Dominio)) { }
                            else{
                                ListViewItem Item = new ListViewItem();
                                Item.Text = Nuevo.Dominio;
                                Item.SubItems.Add(Nuevo.RutaDominio);
                                Item.SubItems.Add("Dominio");
                                ListHostVistuales.Items.Add(Item);
                            }
                        }
                      
                    }
                }
                if (Nuevo.RutaSubDominio == null ) { }
                else {
                    if (Nuevo.SubDominio == null) { }
                    else{
                        if (Directory.Exists(Nuevo.RutaSubDominio)){
                            Regex verif = new Regex(@"\b[a-zA-Z0-9]\b");
                            if (verif.IsMatch(Nuevo.SubDominio)) { }
                            else{
                                ListViewItem Item = new ListViewItem();
                                Item.Text = "/" + Nuevo.SubDominio;
                                Item.SubItems.Add(Nuevo.RutaSubDominio);
                                Item.SubItems.Add("Sub dominio");
                                ListHostVistuales.Items.Add(Item);
                            }
                        }
                       
                    }
                }
                GuardarConfiguracion();
                leer();
            }
        }
        /// <summary>
        /// Escribi al archivo de confiracion apache para los
        /// Dominios locales
        /// </summary>
        private void Escribir(){
            try{
                StreamWriter Escrivier = new StreamWriter(Application.StartupPath + @"\Config\HosAlt.conf", false);
                Escrivier.Write(Escribir_Configuracion_.ToString());
                Escrivier.Close();
            }
            catch (Exception dsd){
                MessageBox.Show(dsd.Message);
            }
        }

        /// <summary>
        /// Escribi al archivo host del windows
        /// </summary>
        /// <param name="Nombre"></param>
        private void EscribirDriver()
        {
            Computer Rescatar = new Computer();
            String valor = "# Copyright (c) 1993-1999 Microsoft Corp." + Environment.NewLine +
    "# Éste es un ejemplo de archivo HOSTS usado por Microsoft TCP/IP para Windows." + Environment.NewLine +
    "# Este archivo contiene las asignaciones de las direcciones IP a los nombres de" + Environment.NewLine +
    "# host. Cada entrada debe permanecer en una línea individual. La dirección IP" + Environment.NewLine +
    "# debe ponerse en la primera columna, seguida del nombre de host correspondiente." + Environment.NewLine +
    "# La dirección IP y el nombre de host deben separarse con al menos un espacio." + Environment.NewLine +
    "# También pueden insertarse comentarios (como éste) en líneas individuales" + Environment.NewLine +
    "# o a continuación del nombre de equipo indicándolos con el símbolo \"#\"" + Environment.NewLine +
    "# Por ejemplo:" + Environment.NewLine +
    "#      102.54.94.97     rhino.acme.com          # servidor origen" + Environment.NewLine +
    "#      38.25.63.10     x.acme.com              # host cliente x" + Environment.NewLine +
    Escribir_Host_Configu_.ToString();
            
       String Unidad=Rescatar.FileSystem.SpecialDirectories.ProgramFiles.Substring(0, 3);
       StreamWriter Escrivier = new StreamWriter(Unidad + @"WINDOWS\system32\drivers\etc\hosts",false );
       Escrivier.Write(valor);
       Escrivier.Close();  
        }

        private string Dominio_;
        private string Ruta_;
        private void leer()
        {
            ListHostVistuales.Items.Clear () ;
            ListHostVistuales.BeginUpdate();
            StreamReader Leer = new StreamReader(Application.StartupPath + @"\Config\HosAlt.conf");
            String Lista="";
            //"/Alias /"
            Regex Rgis=new Regex(@"Alias [a-zA-Z\""\/]");
            Regex Muestr1 = new Regex("DocumentRoot [a-zA-Z/\"]");
            Regex Muestr2 = new Regex("ServerName [a-zA-Z]");
            Regex ruta = new Regex(@"\b[/a-zA-Z]\b");
            Regex EstractRuta = new Regex(@"\b[\/\:a-zA-Z\s]*\b");
            Regex Dominio = new Regex(@"\b(www)+\.[a-zA-Z\d]+\.[a-zA-Z]\b"); 
                while ((Lista = Leer.ReadLine()) != null)
                {
                   
                    if (Muestr1.IsMatch(Lista) || Rgis.IsMatch(Lista) || Muestr2.IsMatch(Lista)){
                       
                        if (Rgis.IsMatch(Lista)){
                            ListViewItem Item = new ListViewItem();
                            String[] Muestra = Lista.Split(new char[] { ' ' });
                            try {
                                for (int i = 1; i <= Muestra.Length; i++) {
                                    if (Muestra[i] != "") {
                                      
                                        if (ruta.IsMatch(Muestra[i].ToString())){
                                       
                                            Ruta_=(Muestra[i].ToString().Substring(1, Muestra[i].ToString().Length - 2));
                                        }
                                        else{
                                        
                                           Dominio_= ( Muestra[i].ToString());
                                        }

                                       
                                    }
                                   
                                }
                            }
                            catch (Exception es){
                            }
                            Item.Text = Dominio_;
                            Item.SubItems.Add(Ruta_);
                            Item.SubItems.Add("Alias");
                            ListHostVistuales.Items.Add(Item); 
                        }
                        if (Muestr2.IsMatch(Lista) ||Muestr1.IsMatch(Lista)) {
                            ListViewItem Item = new ListViewItem();
                            String[] Muestra = Lista.Split(new char[] { ' ' });
                            try
                            {
                                for (int i = 1; i <= Muestra.Length; i++){
                                    if (Muestra[i] != ""){
                                        if (Dominio.IsMatch(Muestra[i].ToString())){}
                                        else {
                                            if (ruta.IsMatch(Muestra[i].ToString())){
                                           // EstractRuta
                                            Ruta_ = (Muestra[i].ToString().Substring(1, Muestra[i].ToString().Length - 2));
                                            }
                                            else {
                                                Item.Text =Muestra[i].ToString() ;
                                                Item.SubItems.Add(Ruta_);
                                                Item.SubItems.Add("Dominio");
                                                ListHostVistuales.Items.Add(Item);
                                            }
                                            
                                        }
                                        
                                    }
                                   
                                }
                              
                            }
                            catch (Exception es) { }
                            
                        }

                    }

                }
                
                Leer.Close();
              
                ListHostVistuales.EndUpdate();
            }
 
        }

    }

