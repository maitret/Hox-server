﻿//Entorno de desarrollo para aplicaciones web Alternativa a Xampp, Wamp Appserv y demás, 
// Copyright (C ) Rodrigo Chambi Q, Email infohoxserver@asqki.com http://www.hoxserver.asqki.com
//
// Este programa es software libre; usted puede redistribuirlo y / o
// Modificarlo bajo los términos de la Licencia Pública General de GNU
// Publicada por la Free Software Foundation; ya sea la versión 2
// De la Licencia, o (a su elección) cualquier versión posterior .
//
// Este programa se distribuye con la esperanza de que sea útil,
// Pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de
// COMERCIALIZACIÓN o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. ver el

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Text;
using System.Text.RegularExpressions;
namespace Hox
{
	/// <summary>
	/// Description of ChangePHP.
	/// </summary>
	public partial class ChangePHP : Form
	{
		public ChangePHP(){
			InitializeComponent();
			this.button1.Click += new System.EventHandler(this.Button1Click);
		//	this.Load += new System.EventHandler(CargarPhpver);
		CargarPhpver();
		}
		 private StringBuilder Escribir_Configuracion_=new  StringBuilder ();
	 public 	void CargarPhpver(){
		 	try{
		 	
		 	String lerr=Application.StartupPath + @"\Config\Hox.conf";
			 StreamReader Leer = new StreamReader(lerr);
			 String Lista="";
		    Regex Rgis1=new Regex(@"LoadModule php7_module");
		    Regex Rgis2=new Regex(@"LoadModule php5_module");
		    while ((Lista = Leer.ReadLine()) != null){
			 	if (Rgis1.IsMatch(Lista)){
		    		comboBox1.Text="PHP 7.0";
		    		RutaPHP_=Rutacarpeta +"php7";
		    	}
		    	if (Rgis2.IsMatch(Lista)){
		    		comboBox1.Text="PHP 5.6";
		    		RutaPHP_=Rutacarpeta +"php5";
		    	}
		    }
		 	}catch(Exception es){
		 	
		 	
		 	}
			
			 }
		 
		private String Rutacarpeta=Application.StartupPath +@"\Programas\";
		void ComboBox1SelectedIndexChanged(object sender, EventArgs e){
		 	
		
		 	try{
		 	//Eliminando el archivo
			if(File.Exists(Application.StartupPath + @"\Config\Hox.conf")){
				File.Delete(Application.StartupPath + @"\Config\Hox.conf");
			}
			switch(comboBox1.Text){
				case "PHP 7.0":
					RutaPHP_=Rutacarpeta+"php7";
					 Escribir_Configuracion_.AppendLine("#Se establece la configuracion de ejecucion para  " + comboBox1.Text);
					 Escribir_Configuracion_.AppendLine("LoadFile "+RutaPHP_+"\\php7ts.dll");
                      Escribir_Configuracion_.AppendLine("LoadFile "+RutaPHP_+"\\libpq.dll");
					 Escribir_Configuracion_.AppendLine("LoadModule php7_module \""+RutaPHP_+"\\php7apache2_4.dll\"");
					 Escribir_Configuracion_.AppendLine("AddHandler application/x-httpd-php .php");
					 Escribir_Configuracion_.AppendLine("AddType application/x-httpd-php .html .html .asp");
					 Escribir_Configuracion_.AppendLine("PHPIniDir \""+RutaPHP_+"\"");
					break;
				case "PHP 5.6":
					RutaPHP_=Rutacarpeta+"php5";
					 Escribir_Configuracion_.AppendLine("#Se establece la configuracion de ejecucion para  " + comboBox1.Text);
					  Escribir_Configuracion_.AppendLine("LoadFile "+RutaPHP_+"\\php5ts.dll");
                      Escribir_Configuracion_.AppendLine("LoadFile "+RutaPHP_+"\\libpq.dll");
					 Escribir_Configuracion_.AppendLine("AddHandler application/x-httpd-php .php");
					 Escribir_Configuracion_.AppendLine("AddType application/x-httpd-php .html .html");
					 Escribir_Configuracion_.AppendLine("LoadModule php5_module \""+RutaPHP_+"\\php5apache2_4.dll\"");
					 Escribir_Configuracion_.AppendLine("PHPIniDir \""+RutaPHP_+"\"");
					 Escribir_Configuracion_.AppendLine("<IfModule dir_module>");
					 Escribir_Configuracion_.AppendLine("DirectoryIndex  text/html .php .phps .asp");
					 Escribir_Configuracion_.AppendLine("</IfModule>");
					break;
			}
			Escribir_Configuracion_.AppendLine("\n\t");
			 Escribir_Configuracion_.AppendLine("#---------Configuracion de aplicaciones web PHPMYADMIN----------");
			 Escribir_Configuracion_.AppendLine("Alias /phpmyadmin \"/Hox/ApWeb/phpMyAdmin/\"");
			 Escribir_Configuracion_.AppendLine("<Directory \"/Hox/ApWeb/phpMyAdmin/\">");
			 Escribir_Configuracion_.AppendLine("AllowOverride All");
			 Escribir_Configuracion_.AppendLine("Require all granted");
			 Escribir_Configuracion_.AppendLine("</Directory>");
			 
			 Escribir_Configuracion_.AppendLine("\n\t");
			 Escribir_Configuracion_.AppendLine("#---------Configuracion de aplicaciones web PHPPGADMIN----------");
			 Escribir_Configuracion_.AppendLine("Alias /phppgadmin \"/Hox/ApWeb/phpPgAdmin/\"");
			 Escribir_Configuracion_.AppendLine("<Directory \"/Hox/ApWeb/phpPgAdmin/\">");
			 Escribir_Configuracion_.AppendLine("AllowOverride All");
			 Escribir_Configuracion_.AppendLine("Require all granted");
			 Escribir_Configuracion_.AppendLine("</Directory>");
		 	}catch(Exception es){
		 	
		 	}
			
			
		}
		void Button1Click(object sender, EventArgs e){
			CongigurarPhp();
		}
		 
		 private void CongigurarPhp(){
            try{
		 		
                StreamWriter Escrivier = new StreamWriter(Application.StartupPath + @"\Config\Hox.conf", true);
                Escrivier.Write(Escribir_Configuracion_.ToString());
                Escrivier.Flush();
                Escrivier.Close();
            }
            catch (Exception dsd){
                MessageBox.Show(dsd.Message);
            }
        }
		
		private static string RutaPHP_=string.Empty;
		/// <summary>
		/// Retorna ruta del PHP
		/// </summary>
		public static string PHPRuta{
			get{return RutaPHP_;}
			set{ RutaPHP_=value;}
		
		}


		
		
	}
}
