﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FastColoredTextBoxNS;
using System.Globalization; 
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        AutocompleteMenu popupMenu;
        public Form1()
        {
            InitializeComponent();

           
            //generate 456976 words

            popupMenu = new AutocompleteMenu(fastColoredTextBox1 );
            String[] sources = new String[] { "if", "for", "for", "funtion","victor" };
            //
            var items = new List<AutocompleteItem>();
            
            foreach (var item in sources)
            {
                items.Add(new AutocompleteItem(item) { ImageIndex = 0 });
            }
            popupMenu.Items.SetAutocompleteItems(items);
            popupMenu.Items.ImageList = imageList1;   
            popupMenu.Items.MaximumSize = new System.Drawing.Size(200, 300);
            popupMenu.Items.Width = 200;
            popupMenu.Items.SelectedColor = Color.Blue;  
            popupMenu.Items.Font = new Font("Tahoma", 10, FontStyle.Regular );         
            //popupMenu.SearchPattern = @"[\w]";
             
           
           
             
            //size of popupmenu

            this.Load += new EventHandler(Form1_Load);
            fastColoredTextBox1.TextChanged += new EventHandler<TextChangedEventArgs>(fastColoredTextBox1_TextChanged);
            fastColoredTextBox1.KeyDown += new KeyEventHandler(fastColoredTextBox1_KeyDown);
        }

       
        void fastColoredTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyData == (Keys.Tab  | Keys.Control))
            //{


            //    popupMenu.Show(true);
            //    e.Handled = true;
            //}

            if (e.KeyData  == (Keys.Control | Keys.Tab ))
            {

                popupMenu.Show(true);
                e.Handled = true;
            
            }
            
        }

        void fastColoredTextBox1_TextChanged(object sender, TextChangedEventArgs e)
        {
             

            HTMLSyntaxHighlight(fastColoredTextBox1.VisibleRange);   
        
            //marka los index
            e.ChangedRange.ClearFoldingMarkers();
            //set markers for folding
           e.ChangedRange.SetFoldingMarkers("{", "}");

        }
      
        Style BlueStyle = new TextStyle(Brushes.Red , null, FontStyle.Bold );
        Style Blue = new TextStyle(Brushes.Blue , null, FontStyle.Regular);
        Style MaroonStyle = new TextStyle(Brushes.Maroon, null, FontStyle.Regular);
        Style Comentario = new TextStyle(Brushes.Red , null, FontStyle.Regular);

        void Form1_Load(object sender, EventArgs e)
        {
           
        }    
        private void HTMLSyntaxHighlight(Range range)
        {
            range.ClearStyle(BlueStyle, MaroonStyle, Blue);

            //tag brackets highlighting
            //<[^>]+>
            range.SetStyle(BlueStyle, @"<\?(php|PHP)|\?+>");
            String[] PalabrasReservadas = new String[] { "for", "if", "switch", "victor" };
            foreach (String Valor in PalabrasReservadas)
            {
                range.SetStyle(Blue, Valor);
            }
            //cOMENTARIO EN LINEA
            range.SetStyle(Comentario, @"(//){1}[\x14-\xFF]*"); 
            //cOMENTARIO LINEA MULTIPLE

            range.SetStyle(Comentario, @"/\*[\x14-\xFF\x13]+\*/"); 
 
            range.SetStyle(Comentario, @"(/\*.*?\*/)|(.*\*/)");  
            range.SetStyle(Blue, @"""[^""]*""");
            //Simbolo del dolar con $variable
            range.SetStyle(Blue ,@"\x24+[a-zA-Z]*");  
            //tag name
        //    
        //    //end of tag
        //    range.SetStyle(MaroonStyle, @"</(?<range>\w+)>");
        //    //attributes
        //    range.SetStyle(RedStyle, @"(?<range>\S+?)='[^']*'|(?<range>\S+)=""[^""]*""|(?<range>\S+)=\S+");
        //    //attribute values
        //    range.SetStyle(BlueStyle, @"\S+?=(?<range>'[^']*')|\S+=(?<range>""[^""]*"")|\S+=(?<range>\S+)");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CharConverter DD=new CharConverter();
                
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

       
    }

    
}
